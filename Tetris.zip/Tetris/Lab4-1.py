#!/usr/bin/python
# -*- coding: utf-8 -*-

# tetris.py
#更改的地方:
#1. 改变了窗口大小
#2. 给程序增加了图标
#3. 修改了程序在Windows下的不能移动方块的bug, 使得方向等控制键可以使用
#4. 增加了选择level的功能
#5. 增加了status bar 的显示信息, 可以告知消去的行数, 修改了分数算法
#6. 将窗口分成不同的列, 使得用户不容易看错列
#7. 增加了告知玩家下一个方块形状的功能
#8. 增加了记录最佳成绩的功能
#9. 增加了无须重新启动就可以重新玩下一局的功能
#10. 增加了不同操作所对应的音效
#11. 由于我认为因为大家都装有输入法,用字母键控制会有问题, 所以将one line down & 暂停 对应的键改为  CTRL 和 SHIFT
#12. 增加帮助HELP信息


import wx
import random
import sys
import os
import time
import cPickle as pickle
from highscores import HighScores
from AboutDialog import AboutDialog
from HighscoresDialog import HighscoresDialog


   
class Tetris(wx.Frame):
    
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(420, 440))
        ico = wx.Icon('tetris.bmp', wx.BITMAP_TYPE_ICO)
        self.SetIcon(ico)
        self.bgcolor = wx.Colour(234, 234, 244)
        self.initFrame()


    def initFrame(self):
        #LevelHelp(None, "Level Selection & Help", (270, 300))
        self.board = Board(self)
	#self.MakeMenuBar()
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText('Level:' + str(self.board.level) + '  Remove:' + str(self.board.numLinesRemoved) \
        + '  Score:' + str(self.board.level * self.board.numLinesRemoved) + '  Best:'+ str(self.board.BestScore) )
        self.board.SetFocus()
        self.board.start()
        self.Centre()
        self.Show(True)
        self.Bind(wx.EVT_CLOSE, self.OnCloseWindow)
        self.MakeMenuBar()
		
    def MenuData(self):
         return (("&Game",
                     ("&New\tEnter", "New game", self.OnNewGameButton),
                     ("&Restart\tCtrl-N", "Restart game", self.OnRestartGameButton),
                    ("&Pause\tCtrl-P", "Pause game", self.OnPause),
                    #("", "", ""),
                    #("&High Scores\tCtrl-H", "Show Scores History", self.OnHighScores),
                    #("", "", ""),
                    ("&Quit\tCtrl-Q", "Quit", self.OnCloseWindow)),
                ("&Help",
                    ("&About\tF1", "About Tetris1.0", self.OnAbout)))

    def CreateMenu(self, menuData):
        menu = wx.Menu()
        for eachLabel, eachStatus, eachHandler in menuData:
            if not eachLabel:
                menu.AppendSeparator()
                continue
            menuItem = menu.Append(-1, eachLabel, eachStatus)
            self.Bind(wx.EVT_MENU, eachHandler, menuItem)
        return menu

    def MakeMenuBar(self):
        menuBar = wx.MenuBar()
        for eachMenuData in self.MenuData():
            menuLabel = eachMenuData[0]
            menuItems = eachMenuData[1:]
            menuBar.Append(self.CreateMenu(menuItems), menuLabel)
        self.SetMenuBar(menuBar)
    
    def OnNewGameButton(self, event):
        if self.board.IsOver:
            self.Destroy()
            Tetris(None, title='Tetris')
    
    def OnRestartGameButton(self, event):
        self.board.pause()
        dlg = wx.MessageDialog(None, "Are you sure you want to restart?",'Tetris 1.0',wx.YES_NO | wx.NO_DEFAULT|wx.ICON_QUESTION)
        result = dlg.ShowModal()
            
        if result == wx.ID_YES:
            self.Destroy()
            Tetris(None, title='Tetris')
        else:
            self.board.pause()
            
        
    def OnCloseWindow(self, event):
        self.Destroy()  
        
    def OnPause(self, event):
        self.board.pause()
        
    def OnAbout(self, evt):
        self.board.pause()
        dialog = AboutDialog(self)
        dialog.ShowModal()
        dialog.Destroy()
        self.board.pause()
        
    #def OnHighScores(self, evt):
    #    self.ShowHighScores() 
        
    
    
class Board(wx.Panel):
    
    BoardWidth = 10
    BoardHeight = 22
    level = 1
    Speed = 10000
    BestScore = 0
    ID_TIMER = 1
    IsOver = False
    
    
    def __init__(self, parent):
        wx.Panel.__init__(self, parent)    
        self.initBoard()
        
    def initBoard(self):    
        
        image = [ wx.Image( name="1.bmp", type=wx.BITMAP_TYPE_BMP),
				  wx.Image( name="2.bmp", type=wx.BITMAP_TYPE_BMP ),
				  wx.Image( name="3.bmp", type=wx.BITMAP_TYPE_BMP ),
				  wx.Image( name="4.bmp", type=wx.BITMAP_TYPE_BMP ),
				  wx.Image( name="5.bmp", type=wx.BITMAP_TYPE_BMP ),
				  wx.Image( name="6.bmp", type=wx.BITMAP_TYPE_BMP ),
				  wx.Image( name="7.bmp", type=wx.BITMAP_TYPE_BMP )]
        self.bmp = [ image[0].ConvertToBitmap(), 
					 image[1].ConvertToBitmap(), 
					 image[2].ConvertToBitmap(),
					 image[3].ConvertToBitmap(),
					 image[4].ConvertToBitmap(),
					 image[5].ConvertToBitmap(),
					 image[6].ConvertToBitmap()]
	
	'''—————使用box设置布局—————'''
        
        #左半部为游戏图形部分
        self.pn1 = wx.Panel(self, -1, style = wx.SUNKEN_BORDER | wx.WANTS_CHARS)
        self.pn1.SetBackgroundColour(u"White")
        box = wx.BoxSizer(wx.HORIZONTAL)
        box.Add(self.pn1, 5, wx.EXPAND | wx.ALL, 3)
        #右半部为数据UI
        Infobox = wx.BoxSizer(wx.VERTICAL)
        font = wx.Font(8, wx.MODERN, wx.NORMAL, wx.BOLD)
        #分数信息
        text1 = wx.StaticText(self, label = u"Next Shape")
        text1.SetFont(font)
        #self.score = wx.TextCtrl(self, size = (100, 15),
        #                         style = wx.TE_READONLY | wx.TE_CENTER)
        #self.score.SetFont(font)
        #self.score.SetValue("0")
        self.nxtshp = wx.EmptyBitmap
        mybitmap = wx.StaticBitmap(self, -1, self.nxtshp)
        Infobox.Add(text1, 2, wx.CENTER | wx.BOTTOM, 15)
        Infobox.Add(mybitmap, 1)
        Infobox.Add((-1, 50))
        ##等级信息
        #text2 = wx.StaticText(self, label = u"当 前 等 级")
        #text2.SetFont(font)
        #self.LevTxt = wx.TextCtrl(self, size = (100, 15),
        #                         style = wx.TE_READONLY | wx.TE_CENTER)
        #self.LevTxt.SetFont(font)
        #self.LevTxt.SetValue("1")
        #Infobox.Add(text2, 2, wx.CENTER | wx.BOTTOM, 15) 
        #Infobox.Add(self.LevTxt, 2, wx.CENTER | wx.BOTTOM, 20)
        #Infobox.Add((-1, 50))
        ##目标信息
        #text3 = wx.StaticText(self, label = u"当 前 目 标")
        #text3.SetFont(font)
        #self.TskTxt = wx.TextCtrl(self, size = (100, 15),
        #                         style = wx.TE_READONLY | wx.TE_CENTER)
        #self.TskTxt.SetFont(font)
        #self.TskTxt.SetValue("10")
        #Infobox.Add(text3, 2, wx.CENTER | wx.BOTTOM, 15)
        #Infobox.Add(self.TskTxt, 2, wx.CENTER | wx.BOTTOM, 20)
        #Infobox.Add((-1, 40))
        
        box.Add(Infobox, 0, wx.EXPAND | wx.ALL, 10)

        self.SetSizer(box)
        '''———————布局完成———————'''
	
        Board.level = self.chooseLevel()
        #LevelHelp(self, "Level Selection & Help", (270, 300))
        Board.Speed = 1000 / Board.level
        self.timer = wx.Timer(self, Board.ID_TIMER)
        self.isWaitingAfterLine = False
        self.curPiece = Shape()
        self.nextPiece = Shape()
        self.curX = 0
        self.curY = 0
        self.numLinesRemoved = 0
        self.board = []

        self.isStarted = False
        self.isPaused = False

        self.pn1.Bind(wx.EVT_PAINT, self.OnPaint)
        self.pn1.Bind(wx.EVT_KEY_DOWN, self.OnKeyDown)
        self.Bind(wx.EVT_TIMER, self.OnTimer, id=Board.ID_TIMER)

        self.clearBoard()
    
    def SetNextShape(self):         #指定面板数值
        self.nxshp = bmp[self.nextPiece.nxtShapeIndex-1]
        
    def chooseLevel(self):
       #while True:
       #     try:
       #         dlg = wx.TextEntryDialog(None, u'Enter a level in 1 to 5.', 'Level')
       #         dlg.ShowModal()
       #         integer = int(dlg.GetValue())
       #     except ValueError: 
       #         wx.MessageDialog(None, "Enter a level in 1 to 5", "Warning!", wx.OK | wx.ICON_WARNING).ShowModal()
       #     else:
       #         if 1 <= integer <= 5: # this is faster
       #             break
       choices = ["novice", "senior", "expert"]
       level = {}
       level["novice"] = 1
       level["senior"] = 2
       level["expert"] = 4
       
       dialog = wx.SingleChoiceDialog(None, "Pick A Level", "Level Selector",
            choices)
       if dialog.ShowModal() == wx.ID_OK:
            #print "You selected: %s\n" % dialog.GetStringSelection()

            sound = wx.Sound('ckm_levelup.wav')
            sound.Play(wx.SOUND_ASYNC)
            return level[ dialog.GetStringSelection() ]

    def shapeAt(self, x, y):
        #print 'shapeAt ' + str((y * Board.BoardWidth) + x)
        return self.board[(y * Board.BoardWidth) + x]

    def setShapeAt(self, x, y, shape):
        
        self.board[(y * Board.BoardWidth) + x] = shape

    def squareWidth(self):
        return self.pn1.GetClientSize().GetWidth() / Board.BoardWidth

    def squareHeight(self):
        return self.pn1.GetClientSize().GetHeight() / Board.BoardHeight
        
    def start(self):
        
        if self.isPaused:
            return
        sound = wx.Sound('ckm_start.wav')
        sound.Play(wx.SOUND_ASYNC)
        self.isStarted = True
        self.isWaitingAfterLine = False
        self.numLinesRemoved = 0
        self.clearBoard()

        self.newPiece()
        self.timer.Start(Board.Speed)
        

    def pause(self):
        
        if not self.isStarted:
            return

        self.isPaused = not self.isPaused
        statusbar = self.GetParent().statusbar

        if self.isPaused:
            self.timer.Stop()
            sound = wx.Sound('ckm_pause.wav')
            sound.Play(wx.SOUND_ASYNC)
            statusbar.SetStatusText('Paused ' + 'L:' + str(Board.level) + '  Remove:' + str(self.numLinesRemoved) + \
            '  Score:' + str(Board.level * self.numLinesRemoved) + '  Best:'+ str(Board.BestScore))
        else:
            sound = wx.Sound('ckm_start.wav')
            sound.Play(wx.SOUND_ASYNC)
            self.timer.Start(Board.Speed)
            if Board.BestScore < Board.level * self.numLinesRemoved:
                    Board.BestScore = Board.level * self.numLinesRemoved
            statusbar.SetStatusText('Level:' + str(Board.level) + '  Remove:' + str(self.numLinesRemoved) + \
            '  Score:' + str(Board.level * self.numLinesRemoved) + '  Best:'+ str(Board.BestScore)  )

        self.pn1.Refresh()

    def clearBoard(self):
        
        for i in range(Board.BoardHeight * Board.BoardWidth):
            self.board.append(Tetrominoes.NoShape)

    def OnPaint(self, event):
        dc = wx.PaintDC(self.pn1)       
        size = self.pn1.GetClientSize()
        
        for i in range(size.GetWidth()/ Board.BoardWidth):
            dc.DrawLine(2.52*i*Board.BoardWidth, 0, 2.52*i*Board.BoardWidth, size.GetHeight())#sorry for the magic number 2.52
        img_nxt = wx.Image( name="key.bmp", type=wx.BITMAP_TYPE_BMP)
				 
        img_nxt = img_nxt.ConvertToBitmap()			 
        dc.DrawBitmap( img_nxt, 0, 0)
        dc.DrawBitmap( self.bmp[self.nextPiece.nxtShapeIndex-1], 5, 15)
        #Board.box.Add(bmp[self.nextPiece.nxtShapeIndex-1])
        #self.SetSizer(Board.box)
        boardTop = size.GetHeight() - Board.BoardHeight * self.squareHeight()
        for i in range(Board.BoardHeight):
            for j in range(Board.BoardWidth):
                shape = self.shapeAt(j, Board.BoardHeight - i - 1)
                if shape != Tetrominoes.NoShape:
                    self.drawSquare(dc,
                        0 + j * self.squareWidth(),
                        boardTop + i * self.squareHeight(), shape)

        if self.curPiece.shape() != Tetrominoes.NoShape:
            for i in range(4):
                x = self.curX + self.curPiece.x(i)
                y = self.curY - self.curPiece.y(i)
                self.drawSquare(dc, 0 + x * self.squareWidth(),
                    boardTop + (Board.BoardHeight - y - 1) * self.squareHeight(),
                    self.curPiece.shape())


    def OnKeyDown(self, event):
        
        if not self.isStarted or self.curPiece.shape() == Tetrominoes.NoShape:
            event.Skip()
            return

        keycode = event.GetKeyCode()

        if keycode == wx.WXK_SHIFT:
            self.pause()
            return
        if self.isPaused:
            return
        elif keycode == wx.WXK_LEFT:
            sound = wx.Sound('dd_move.wav')
            sound.Play(wx.SOUND_ASYNC)
            self.tryMove(self.curPiece, self.curX - 1, self.curY)
        elif keycode == wx.WXK_RIGHT:
            sound = wx.Sound('dd_move.wav')
            sound.Play(wx.SOUND_ASYNC)
            self.tryMove(self.curPiece, self.curX + 1, self.curY)
        elif keycode == wx.WXK_DOWN:
            self.tryMove(self.curPiece.rotatedRight(), self.curX, self.curY)
        elif keycode == wx.WXK_UP:
            self.tryMove(self.curPiece.rotatedLeft(), self.curX, self.curY)
        elif keycode == wx.WXK_SPACE:
            self.dropDown()
        elif keycode == wx.WXK_CONTROL:
            self.oneLineDown()
        else:
            event.Skip()


    def OnTimer(self, event):
        
        if event.GetId() == Board.ID_TIMER:
            if self.isWaitingAfterLine:
                self.isWaitingAfterLine = False
                self.newPiece()
            else:
                self.oneLineDown()
        else:
            event.Skip()


    def dropDown(self):
        
        newY = self.curY
        
        while newY > 0:
            if not self.tryMove(self.curPiece, self.curX, newY - 1):
                break
            newY -= 1
            sound = wx.Sound('dd_drop.wav')
            sound.Play(wx.SOUND_ASYNC)

        self.pieceDropped()

    def oneLineDown(self):
        
        if not self.tryMove(self.curPiece, self.curX, self.curY - 1):
            self.pieceDropped()
            sound = wx.Sound('dd_down.wav')
            sound.Play(wx.SOUND_ASYNC)
            

    def pieceDropped(self):
        
        for i in range(4):
            x = self.curX + self.curPiece.x(i)
            y = self.curY - self.curPiece.y(i)
            self.setShapeAt(x, y, self.curPiece.shape())

        self.removeFullLines()

        if not self.isWaitingAfterLine:
            self.newPiece()


    def removeFullLines(self):
    
        numFullLines = 0

        statusbar = self.GetParent().statusbar

        rowsToRemove = []

        for i in range(Board.BoardHeight):
            n = 0
            for j in range(Board.BoardWidth):
                if not self.shapeAt(j, i) == Tetrominoes.NoShape:
                    n = n + 1

            if n == 10:
                rowsToRemove.append(i)

        rowsToRemove.reverse()

        for m in rowsToRemove:
            for k in range(m, Board.BoardHeight):
                for l in range(Board.BoardWidth):
                        self.setShapeAt(l, k, self.shapeAt(l, k + 1))

            numFullLines = numFullLines + len(rowsToRemove)

            if numFullLines > 0:
                self.numLinesRemoved += numFullLines
                sound = wx.Sound('dd_rowclear.wav')
                sound.Play(wx.SOUND_ASYNC)
                if Board.BestScore < Board.level * self.numLinesRemoved:
                    Board.BestScore = Board.level * self.numLinesRemoved
                statusbar.SetStatusText('Level:' + str(Board.level) + '  Remove:' + str(self.numLinesRemoved) + \
                '  Score:' + str(Board.level * self.numLinesRemoved) + '  Best:'+ str(Board.BestScore)   )

                self.isWaitingAfterLine = True
                self.curPiece.setShape(Tetrominoes.NoShape)
                self.pn1.Refresh()

    def gameOver(self):
        Board.IsOver = True
        if Board.BestScore < Board.level * self.numLinesRemoved:
                    Board.BestScore = Board.level * self.numLinesRemoved
        statusbar = self.GetParent().statusbar
        sound = wx.Sound('ckm_highscore.wav')
        sound.Play(wx.SOUND_ASYNC)
        statusbar.SetStatusText('Game Over '+ 'L:' + str(Board.level)  + '  Remove:' + str(self.numLinesRemoved) +\
        '  Score:' + str(Board.level * self.numLinesRemoved) + '  Best:'+ str(Board.BestScore) )
        time.sleep(2)
        statusbar.SetStatusText('Want to replay? Press Enter to replay' )


    def newPiece(self):
        self.curPiece = self.nextPiece
        self.nextPiece.setRandomShape()
        #print 'next peiece ' + str(self.nextPiece.nxtShapeIndex)
        self.curX = Board.BoardWidth / 2 + 1
        self.curY = Board.BoardHeight - 1 + self.curPiece.minY()

        if not self.tryMove(self.curPiece, self.curX, self.curY):
            self.curPiece.setShape(Tetrominoes.NoShape)
            self.timer.Stop()
            self.isStarted = False
            self.gameOver()
                

    def tryMove(self, newPiece, newX, newY):
        
        for i in range(4):
            
            x = newX + newPiece.x(i)
            y = newY - newPiece.y(i)
            
            if x < 0 or x >= Board.BoardWidth or y < 0 or y >= Board.BoardHeight:
                return False
            if self.shapeAt(x, y) != Tetrominoes.NoShape:
                return False

        self.curPiece = newPiece
        self.curX = newX
        self.curY = newY
        self.pn1.Refresh()
        
        return True


    def drawSquare(self, dc, x, y, shape):
        
        colors = ['#000000', '#FF0000', '#00FF00', '#00FFFF',
                  '#A000C0', '#FFFF00', '#0000FF', '#E0A000']

        light = ['#000000', '#F89FAB', '#79FC79', '#7979FC', 
                 '#FCFC79', '#FC79FC', '#79FCFC', '#FCC600']

        dark = ['#000000', '#803C3B', '#3B803B', '#3B3B80', 
                 '#80803B', '#803B80', '#3B8080', '#806200']

        pen = wx.Pen(light[shape])
        pen.SetCap(wx.CAP_PROJECTING)
        dc.SetPen(pen)

        dc.DrawLine(x, y + self.squareHeight() - 1, x, y)
        dc.DrawLine(x, y, x + self.squareWidth() - 1, y)

        darkpen = wx.Pen(dark[shape])
        darkpen.SetCap(wx.CAP_PROJECTING)
        dc.SetPen(darkpen)

        dc.DrawLine(x + 1, y + self.squareHeight() - 1,
            x + self.squareWidth() - 1, y + self.squareHeight() - 1)
        dc.DrawLine(x + self.squareWidth() - 1, 
        y + self.squareHeight() - 1, x + self.squareWidth() - 1, y + 1)

        dc.SetPen(wx.TRANSPARENT_PEN)
        dc.SetBrush(wx.Brush(colors[shape]))
        dc.DrawRectangle(x + 1, y + 1, self.squareWidth() - 2, 
        self.squareHeight() - 2)



class Tetrominoes(object):
    
    NoShape = 0
    ZShape = 1
    SShape = 2
    LineShape = 3
    TShape = 4
    SquareShape = 5
    LShape = 6
    MirroredLShape = 7

    

class Shape(object):
    nxtShapeIndex = 1;
    ii = True
    randcur = random.randint(1, 7)
    randnext = 1
    coordsTable = (
        ((0, 0),     (0, 0),     (0, 0),     (0, 0)),
        ((0, -1),    (0, 0),     (-1, 0),    (-1, 1)),
        ((0, -1),    (0, 0),     (1, 0),     (1, 1)),
        ((0, -1),    (0, 0),     (0, 1),     (0, 2)),
        ((-1, 0),    (0, 0),     (1, 0),     (0, 1)),
        ((0, 0),     (1, 0),     (0, 1),     (1, 1)),
        ((-1, -1),   (0, -1),    (0, 0),     (0, 1)),
        ((1, -1),    (0, -1),    (0, 0),     (0, 1))
    )

    def __init__(self):
        self.coords = [[0,0] for i in range(4)]
        self.pieceShape = Tetrominoes.NoShape
        
        self.setShape(Tetrominoes.NoShape)

    def shape(self):
        
        return self.pieceShape

    def setShape(self, shape):
        
        table = Shape.coordsTable[shape]
        for i in range(4):
            for j in range(2):
                self.coords[i][j] = table[i][j]

        self.pieceShape = shape

    def setRandomShape(self):
        
        if Shape.ii == True:
            self.setShape( Shape.randcur )
            Shape.randnext = random.randint(1, 7)
            Shape.nxtShapeIndex = Shape.randnext
            Shape.ii = False
        else:
            self.setShape( Shape.randnext )
            Shape.randcur = random.randint(1, 7)
            Shape.nxtShapeIndex = Shape.randcur
            Shape.ii = True
            
        
    def x(self, index):
        
        return self.coords[index][0]

    def y(self, index):
        
        return self.coords[index][1]

    def setX(self, index, x):
        
        self.coords[index][0] = x

    def setY(self, index, y):
        
        self.coords[index][1] = y

    def minX(self):
        
        m = self.coords[0][0]
        for i in range(4):
            m = min(m, self.coords[i][0])

        return m

    def maxX(self):
        
        m = self.coords[0][0]
        for i in range(4):
            m = max(m, self.coords[i][0])

        return m

    def minY(self):
        
        m = self.coords[0][1]
        for i in range(4):
            m = min(m, self.coords[i][1])

        return m

    def maxY(self):
        
        m = self.coords[0][1]
        
        for i in range(4):
            m = max(m, self.coords[i][1])

        return m

    def rotatedLeft(self):
        
        sound = wx.Sound('dd_rotate.wav')
        sound.Play(wx.SOUND_ASYNC)
        if self.pieceShape == Tetrominoes.SquareShape:
            return self
        
        result = Shape()
        result.pieceShape = self.pieceShape
        
        for i in range(4):
            result.setX(i, self.y(i))
            result.setY(i, -self.x(i))

        return result

    def rotatedRight(self):
        sound = wx.Sound('dd_rotate.wav')
        sound.Play(wx.SOUND_ASYNC)
        if self.pieceShape == Tetrominoes.SquareShape:
            return self

        result = Shape()
        result.pieceShape = self.pieceShape
        
        for i in range(4):
            result.setX(i, -self.y(i))
            result.setY(i, self.x(i))

        return result


app = wx.App()
tetris = Tetris(None, title='Tetris')
app.MainLoop()