#!/usr/bin/python
# -*- coding: utf8 -*-
# tetris.py

'''—————————增加功能—————————'''
#难度划分
#难度信息面板
#存/读档

import wx
import random
import math

try:
    import cPickle as pickle
except ImportError:
    import pickle

class Tetris(wx.Frame):
    
    def __init__(self, parent, title):
        wx.Frame.__init__(self, parent, title=title, size=(420, 440)) 
        self.initFrame()
    
    def initFrame(self):
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetStatusText('0')
        self.board = Board(self)
        self.board.SetFocus()
        self.board.start()

        self.Centre()
        self.Show(True)

        self.menuBar = wx.MenuBar()
        #——————————文件菜单——————————#
        File = wx.Menu()
        File.Append(101, "&Restart")
        File.Append(wx.ID_EXIT, "&Exit")
        self.menuBar.Append(File, "&File")
        #——————————存档菜单——————————#
        Dialog = wx.Menu()
        Dialog.Append(201, u"&Save Data", u"")
        Dialog.Append(202, u"&Load Data", u"")

        self.menuBar.Append(Dialog, u"S/L(&Q)")

        self.SetMenuBar(self.menuBar)

        self.Bind(wx.EVT_MENU, self.OnRestart, id = 101)
        self.Bind(wx.EVT_MENU, self.OnClose, id = wx.ID_EXIT)   
        self.Bind(wx.EVT_MENU, self.SaveData, id = 201)
        self.Bind(wx.EVT_MENU, self.LoadData, id = 202)
    
    def OnRestart(self, evt):
        self.board.Level = 1
        self.board.Task = 10
        self.board.numLinesRemoved = 0
        self.board.isStarted = True
        self.board.isPaused = False
        self.board.SetScore()
        self.board.board = []
        self.board.curPiece = Shape()
        self.board.clearBoard()
        self.board.start()

    def OnClose(self, evt):
        self.Close()
    '''—————————存档功能—————————'''
    def SaveData(self, evt):
        data = open("data.txt", 'wb')
        pickle.dump(self.board.board, data)
        pickle.dump(self.board.Level, data)
        pickle.dump(self.board.Task, data)
        pickle.dump(self.board.numLinesRemoved, data)
        pickle.dump(self.board.curPiece, data)
        pickle.dump(self.board.nextPiece, data)
        pickle.dump(self.board.curX, data)
        pickle.dump(self.board.curY, data)
        pickle.dump(self.board.isStarted, data)
        pickle.dump(self.board.isWaitingAfterLine, data)
        data.close()
    '''—————————读档功能—————————'''
    def LoadData(self, evt):
        data = open("data.txt", "rb")
        self.board.board = pickle.load(data)
        self.board.Level = pickle.load(data)
        self.board.Task = pickle.load(data)
        self.board.numLinesRemoved = pickle.load(data)
        self.board.curPiece = pickle.load(data)
        self.board.nextPiece = pickle.load(data)
        self.board.curX = pickle.load(data)
        self.board.curY = pickle.load(data)
        self.board.isStarted = pickle.load(data)
        self.board.isWaitingAfterLine = pickle.load(data)
        data.close()
        self.board.SetScore()
        self.board.isPaused = False
        self.board.pause()

class Board(wx.Panel):
    
    BoardWidth = 15
    BoardHeight = 20
    Speed = 360
    ID_TIMER = 1
    
    def __init__(self, parent):
        wx.Panel.__init__(self, parent)    
        self.initBoard()

    def initBoard(self):
        '''—————使用box设置布局—————'''
        box = wx.BoxSizer(wx.HORIZONTAL)
        #左半部为游戏图形部分
        self.pn1 = wx.Panel(self, -1, style = wx.SUNKEN_BORDER | wx.WANTS_CHARS)
        self.pn1.SetBackgroundColour(u"Black")
        box.Add(self.pn1, 5, wx.EXPAND | wx.ALL, 3)
        #右半部为数据UI
        Infobox = wx.BoxSizer(wx.VERTICAL)
        font = wx.Font(8, wx.MODERN, wx.NORMAL, wx.BOLD)
        #分数信息
        text1 = wx.StaticText(self, label = u"当 前 分 数")
        text1.SetFont(font)
        self.score = wx.TextCtrl(self, size = (100, 15),
                                 style = wx.TE_READONLY | wx.TE_CENTER)
        self.score.SetFont(font)
        self.score.SetValue("0")
        Infobox.Add(text1, 2, wx.CENTER | wx.BOTTOM, 15)
        Infobox.Add(self.score, 2, wx.CENTER | wx.BOTTOM, 20)
        Infobox.Add((-1, 50))
        #等级信息
        text2 = wx.StaticText(self, label = u"当 前 等 级")
        text2.SetFont(font)
        self.LevTxt = wx.TextCtrl(self, size = (100, 15),
                                 style = wx.TE_READONLY | wx.TE_CENTER)
        self.LevTxt.SetFont(font)
        self.LevTxt.SetValue("1")
        Infobox.Add(text2, 2, wx.CENTER | wx.BOTTOM, 15) 
        Infobox.Add(self.LevTxt, 2, wx.CENTER | wx.BOTTOM, 20)
        Infobox.Add((-1, 50))
        #目标信息
        text3 = wx.StaticText(self, label = u"当 前 目 标")
        text3.SetFont(font)
        self.TskTxt = wx.TextCtrl(self, size = (100, 15),
                                 style = wx.TE_READONLY | wx.TE_CENTER)
        self.TskTxt.SetFont(font)
        self.TskTxt.SetValue("10")
        Infobox.Add(text3, 2, wx.CENTER | wx.BOTTOM, 15)
        Infobox.Add(self.TskTxt, 2, wx.CENTER | wx.BOTTOM, 20)
        Infobox.Add((-1, 40))
        
        box.Add(Infobox, 0, wx.EXPAND | wx.ALL, 10)

        self.SetSizer(box)
        '''———————布局完成———————'''
        self.timer = wx.Timer(self, Board.ID_TIMER)
        self.isWaitingAfterLine = False
        self.curPiece = Shape()
        self.nextPiece = Shape()
        self.curX = 0
        self.curY = 0
        self.numLinesRemoved = 0
        self.Level = 1          #增加游戏难度参数
        self.Task = 10          #增加当前难度目标
        self.board = []

        self.isStarted = False
        self.isPaused = False

        self.pn1.Bind(wx.EVT_PAINT, self.OnPaint)
        self.pn1.Bind(wx.EVT_KEY_DOWN, self.OnKeyDown)
        self.Bind(wx.EVT_TIMER, self.OnTimer, id=Board.ID_TIMER)

        self.clearBoard()

    def SetScore(self):         #指定面板数值
        self.LevTxt.SetValue(str(self.Level))
        self.TskTxt.SetValue(str(self.Task))
        self.score.SetValue(str(self.numLinesRemoved))

        statusbar = self.GetParent().statusbar
        if self.isStarted == False:
            statusbar.SetStatusText("Game over")
        elif self.isPaused == True:
            statusbar.SetStatusText("Pause")
        else:
            statusbar.SetStatusText(str(self.numLinesRemoved))
        self.timer.Start(Board.Speed - 25*(self.Level-1))

    def shapeAt(self, x, y):
        return self.board[(y * Board.BoardWidth) + x]

    def setShapeAt(self, x, y, shape):
        self.board[(y * Board.BoardWidth) + x] = shape

    def squareWidth(self):
        return self.pn1.GetClientSize().GetWidth() / Board.BoardWidth

    def squareHeight(self):
        return self.pn1.GetClientSize().GetHeight() / Board.BoardHeight

    def start(self):
        if self.isPaused: return

        self.isStarted = True
        self.isWaitingAfterLine = False
        self.numLinesRemoved = 0
        self.clearBoard()

        self.newPiece()
        self.timer.Start(Board.Speed)

    def pause(self):
        if not self.isStarted: return

        self.isPaused = not self.isPaused
        statusbar = self.GetParent().statusbar

        if self.isPaused:
            self.timer.Stop()
            statusbar.SetStatusText('paused')
            self.score.SetValue('paused')
        else:
            self.timer.Start(Board.Speed - 40*(self.Level-1))
            statusbar.SetStatusText(str(self.numLinesRemoved))
            self.score.SetValue(str(self.numLinesRemoved))

        self.pn1.Refresh()

    def clearBoard(self):
        for i in range(Board.BoardHeight * Board.BoardWidth):
            self.board.append(Tetrominoes.NoShape)

    def OnPaint(self, event):
        
        dc = wx.PaintDC(self.pn1)        

        size = self.pn1.GetClientSize()
        boardTop = size.GetHeight() - Board.BoardHeight * self.squareHeight()
        
        for i in range(Board.BoardHeight):
            for j in range(Board.BoardWidth):
                shape = self.shapeAt(j, Board.BoardHeight - i - 1)
                if shape != Tetrominoes.NoShape:
                    self.drawSquare(dc,
                        0 + j * self.squareWidth(),
                        boardTop + i * self.squareHeight(), shape)

        if self.curPiece.shape() != Tetrominoes.NoShape:
            for i in range(4):
                x = self.curX + self.curPiece.x(i)
                y = self.curY - self.curPiece.y(i)
                self.drawSquare(dc, 0 + x * self.squareWidth(),
                    boardTop + (Board.BoardHeight - y - 1) * self.squareHeight(),
                    self.curPiece.shape())


    def OnKeyDown(self, event):
        
        if not self.isStarted or self.curPiece.shape() == Tetrominoes.NoShape:
            event.Skip()
            return

        keycode = event.GetKeyCode()

        if keycode == ord('P') or keycode == ord('p'):
            self.pause()
            return
        if self.isPaused:
            return
        elif keycode == wx.WXK_LEFT:
            self.tryMove(self.curPiece, self.curX - 1, self.curY)
        elif keycode == wx.WXK_RIGHT:
            self.tryMove(self.curPiece, self.curX + 1, self.curY)
        elif keycode == wx.WXK_DOWN:
            self.tryMove(self.curPiece.rotatedRight(), self.curX, self.curY)
        elif keycode == wx.WXK_UP:
            self.tryMove(self.curPiece.rotatedLeft(), self.curX, self.curY)
        elif keycode == wx.WXK_SPACE:
            self.dropDown()
        elif keycode == ord('D') or keycode == ord('d'):
            self.oneLineDown()
        else:
            event.Skip()

    def OnTimer(self, event):
        
        if event.GetId() == Board.ID_TIMER:
            if self.isWaitingAfterLine:
                self.isWaitingAfterLine = False
                self.newPiece()
            else:
                self.oneLineDown()
        else:
            event.Skip()
        self.SetScore()


    def dropDown(self):
        
        newY = self.curY
        
        while newY > 0:
            if not self.tryMove(self.curPiece, self.curX, newY - 1):
                break
            newY -= 1

        self.pieceDropped()

    def oneLineDown(self): 
        if not self.tryMove(self.curPiece, self.curX, self.curY - 1):
            self.pieceDropped()
            
    def pieceDropped(self):
        for i in range(4):
            x = self.curX + self.curPiece.x(i)
            y = self.curY - self.curPiece.y(i)
            self.setShapeAt(x, y, self.curPiece.shape())

        self.removeFullLines()

        if not self.isWaitingAfterLine:
            self.newPiece()

    def removeFullLines(self):
    
        numFullLines = 0
        rowsToRemove = []

        for i in range(Board.BoardHeight):
            n = 0
            for j in range(Board.BoardWidth):
                if not self.shapeAt(j, i) == Tetrominoes.NoShape:
                    n = n + 1

            if n == Board.BoardWidth:
                rowsToRemove.append(i)

        rowsToRemove.reverse()

        for m in rowsToRemove:
            for k in range(m, Board.BoardHeight):
                for l in range(Board.BoardWidth):
                        self.setShapeAt(l, k, self.shapeAt(l, k + 1))

            numFullLines = numFullLines + len(rowsToRemove)

            if numFullLines > 0:
                self.numLinesRemoved = self.numLinesRemoved + numFullLines
                '''———————基于等级难度参数调整———————'''
                if self.numLinesRemoved >= self.Task:
                    self.Level += 1
                    if self.Level <= 3:
                        self.Task += 20*self.Level
                    elif self.Level <= 5:
                        self.Task += 50*self.Level
                    else:
                        self.Task = pow(10, self.Level-3)
                    
                self.isWaitingAfterLine = True
                self.curPiece.setShape(Tetrominoes.NoShape)
                self.pn1.Refresh()


    def newPiece(self):
        
        self.curPiece = self.nextPiece
        statusbar = self.GetParent().statusbar
        self.nextPiece.setRandomShape()
        self.curX = Board.BoardWidth / 2 + 1
        self.curY = Board.BoardHeight - 1 + self.curPiece.minY()

        if not self.tryMove(self.curPiece, self.curX, self.curY):      
            self.curPiece.setShape(Tetrominoes.NoShape)
            self.timer.Stop()
            self.isStarted = False
            statusbar.SetStatusText('Game over')
            

    def tryMove(self, newPiece, newX, newY):
        
        for i in range(4):    
            x = newX + newPiece.x(i)
            y = newY - newPiece.y(i)
            
            if x < 0 or x >= Board.BoardWidth or y < 0 or y >= Board.BoardHeight:
                return False
            if self.shapeAt(x, y) != Tetrominoes.NoShape:
                return False

        self.curPiece = newPiece
        self.curX = newX
        self.curY = newY
        self.pn1.Refresh()
        
        return True

    def drawSquare(self, dc, x, y, shape):
        
        colors = ['#000000', '#CC6666', '#66CC66', '#6666CC',
                  '#CCCC66', '#CC66CC', '#66CCCC', '#DAAA00']

        light = ['#000000', '#F89FAB', '#79FC79', '#7979FC', 
                 '#FCFC79', '#FC79FC', '#79FCFC', '#FCC600']

        dark = ['#000000', '#803C3B', '#3B803B', '#3B3B80', 
                '#80803B', '#803B80', '#3B8080', '#806200']

        pen = wx.Pen(light[shape])
        pen.SetCap(wx.CAP_PROJECTING)
        dc.SetPen(pen)

        dc.DrawLine(x, y + self.squareHeight() - 1, x, y)
        dc.DrawLine(x, y, x + self.squareWidth() - 1, y)

        darkpen = wx.Pen(dark[shape])
        darkpen.SetCap(wx.CAP_PROJECTING)
        dc.SetPen(darkpen)

        dc.DrawLine(x + 1, y + self.squareHeight() - 1,
            x + self.squareWidth() - 1, y + self.squareHeight() - 1)
        dc.DrawLine(x + self.squareWidth() - 1, 
        y + self.squareHeight() - 1, x + self.squareWidth() - 1, y + 1)

        dc.SetPen(wx.TRANSPARENT_PEN)
        dc.SetBrush(wx.Brush(colors[shape]))
        dc.DrawRectangle(x + 1, y + 1, self.squareWidth() - 2, 
        self.squareHeight() - 2)


class Tetrominoes(object):
    
    NoShape = 0
    ZShape = 1
    SShape = 2
    LineShape = 3
    TShape = 4
    SquareShape = 5
    LShape = 6
    MirroredLShape = 7

class Shape(object):
    
    coordsTable = (
        ((0, 0),     (0, 0),     (0, 0),     (0, 0)),
        ((0, -1),    (0, 0),     (-1, 0),    (-1, 1)),
        ((0, -1),    (0, 0),     (1, 0),     (1, 1)),
        ((0, -1),    (0, 0),     (0, 1),     (0, 2)),
        ((-1, 0),    (0, 0),     (1, 0),     (0, 1)),
        ((0, 0),     (1, 0),     (0, 1),     (1, 1)),
        ((-1, -1),   (0, -1),    (0, 0),     (0, 1)),
        ((1, -1),    (0, -1),    (0, 0),     (0, 1))
    )

    def __init__(self):
        
        self.coords = [[0,0] for i in range(4)]
        self.pieceShape = Tetrominoes.NoShape

        self.setShape(Tetrominoes.NoShape)

    def shape(self):
        
        return self.pieceShape

    def setShape(self, shape):
        
        table = Shape.coordsTable[shape]
        for i in range(4):
            for j in range(2):
                self.coords[i][j] = table[i][j]

        self.pieceShape = shape

    def setRandomShape(self):    
        self.setShape(random.randint(1, 7))

    def x(self, index):
        return self.coords[index][0]

    def y(self, index):
        return self.coords[index][1]

    def setX(self, index, x):
        self.coords[index][0] = x

    def setY(self, index, y):
        self.coords[index][1] = y

    def minX(self):
        m = self.coords[0][0]
        for i in range(4):
            m = min(m, self.coords[i][0])

        return m

    def maxX(self):
        m = self.coords[0][0]
        for i in range(4):
            m = max(m, self.coords[i][0])

        return m

    def minY(self):
        m = self.coords[0][1]
        for i in range(4):
            m = min(m, self.coords[i][1])

        return m

    def maxY(self):
        m = self.coords[0][1]
        for i in range(4):
            m = max(m, self.coords[i][1])

        return m

    def rotatedLeft(self):
        if self.pieceShape == Tetrominoes.SquareShape:
            return self

        result = Shape()
        result.pieceShape = self.pieceShape
        
        for i in range(4):
            result.setX(i, self.y(i))
            result.setY(i, -self.x(i))

        return result

    def rotatedRight(self):
        if self.pieceShape == Tetrominoes.SquareShape:
            return self

        result = Shape()
        result.pieceShape = self.pieceShape
        
        for i in range(4):
            result.setX(i, -self.y(i))
            result.setY(i, self.x(i))

        return result


app = wx.App()
Tetris(None, title='Tetris')
app.MainLoop()
