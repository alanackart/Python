import wx
import wx.grid
import wx.html

import images


about_text = """\
Hello Tetris
"""


scoring_text = """\
The score is computed as follows:

If you remove on a lines in x level, then you will get 
a*x score."""


keys_desc = [
    ('', ''),
    ('Left arrow', 'Move figure left'),
    ('Right arrow', 'Move figure right'),
    ('Down arrow', 'Rotate figure anticlockwise'),
    ('Up arrow', 'Rotate figure clockwise'),
    ('Space', 'Drop figure'),
    ('Ctrl-H', 'Show high scores'),
    ('Ctrl-N', 'New game'),
    ('Ctrl-P', 'Pause / Resume game'),
    ('Ctrl-Q', 'Quit'),
    ('F1', 'About Tetris 1.0'),
    ]


class AboutDialog(wx.Dialog):
    def __init__(self, parent = None):
        wx.Dialog.__init__(self, parent, -1, 'About Tetris 1.0')

        nb = wx.Notebook(self, -1)

        #
        # About
        # 
        aboutPage = wx.Panel(nb, -1)
        sizer = wx.BoxSizer(wx.VERTICAL)
        bitmap = images.getLogoBitmap()
        image = wx.StaticBitmap(aboutPage, -1, bitmap, (0, 0), (bitmap.GetWidth(), bitmap.GetHeight()))
        sizer.Add(image, 0, wx.ALIGN_CENTER | wx.ALL, 10)
        sizer.Add(wx.StaticText(aboutPage, -1, about_text), 0, wx.ALIGN_LEFT | wx.ALL, 10)
        aboutPage.SetSizer(sizer)
        nb.AddPage(aboutPage, "About")
        
        #
        # Keys
        #
        keysPage = wx.Panel(nb, -1)
        
        grid = wx.FlexGridSizer(len(keys_desc), 3, 5, 5)
        
        for key, desc in keys_desc:
            blank_label = wx.StaticText(keysPage, -1, "    ")
            key_label = wx.StaticText(keysPage, -1, "%-14s" % key)
            desc_label = wx.StaticText(keysPage, -1, "%-40s" % desc)
            
            grid.Add(blank_label)
            grid.Add(key_label)
            grid.Add(desc_label)
            
        keysPage.SetSizer(grid)
        nb.AddPage(keysPage, "Keys")
        
        #
        # Scoring 
        #
        scoringPage = wx.Panel(nb, -1)
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(wx.StaticText(scoringPage, -1, scoring_text), 0, wx.ALIGN_LEFT | wx.ALL, 10)

        nb.AddPage(scoringPage, "Scoring")
        
        #
        # Dialog layout
        # 
        sizer = wx.BoxSizer(wx.VERTICAL)
        sizer.Add(nb, 0, wx.ALIGN_CENTRE|wx.ALL, 5)
        btn = wx.Button(self, wx.ID_OK)
        sizer.Add(btn, 0, wx.ALIGN_CENTRE|wx.ALL, 5)

        self.SetSizer(sizer)
        self.Layout()
        self.Fit()
        


if __name__ == "__main__":
    app = wx.PySimpleApp()

    dlg = AboutDialog()
    dlg.ShowModal()
    dlg.Destroy()

    app.MainLoop()

