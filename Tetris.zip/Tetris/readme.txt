Notes on sound effects used by GCUK Blocks

The sound effects are licensed under the GNU GPL

When using these sounds, please credit the designers
and retain the license info. :)

Copyright (c) 2002 ChaotikMind
ckm_start.wav
ckm_levelup.wav
ckm_pause.wav
ckm_quit.wav
ckm_rowclear.wav
ckm_highscore.wav

Copyright (c) 2002 Davy Durham
dd_drop.wav
dd_rotate.wav
dd_rowclear.wav
dd_down.wav
dd_move.wav


format of sounds.txt
sound events [whitespace] filename

no spaces in filename!
