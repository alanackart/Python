import wx

class HighscoresDialog(wx.Dialog):
    def __init__(self, parent, scorelist):
        wx.Dialog.__init__(self, parent, -1, "High Scores")
        
        vbox = wx.BoxSizer(wx.VERTICAL)
        
        panel = wx.Panel(self, -1, style = wx.SUNKEN_BORDER)
        grid = wx.FlexGridSizer(10, 3, 12, 5)
        
        for i in range(10):
            name, score = ("", "") if i >= len(scorelist) else scorelist[i]
            place_label = wx.StaticText(panel, -1, "%3s." % (i + 1))
            name_label = wx.StaticText(panel, -1, "%-50s" % name)
            score_label = wx.StaticText(panel, -1, "%s" % score, size = (60, -1), style = wx.ALIGN_RIGHT)
            
            grid.Add(place_label)
            grid.Add(name_label)
            grid.Add(score_label)
        
        panel.SetSizer(grid)
        grid.Fit(panel)
        
        okay = wx.Button(self, wx.ID_OK)
        okay.SetDefault()
        
        vbox.Add(panel)
        vbox.Add(okay, flag = wx.ALIGN_CENTER)
        
        self.SetSizer(vbox)
        vbox.Fit(self)
