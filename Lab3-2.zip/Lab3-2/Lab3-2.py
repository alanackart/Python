# -*- coding: cp936 -*-

import wx
import myMenu
import os
import sys
import pygame
os.chdir(os.path.dirname(sys.argv[0]))
#import imageFile
#from wx.lib.embeddedimage import PyEmbeddedImage

class MyFrame( wx.Frame ):
	def __init__(self):
		wx.Frame.__init__( self, None, -1, u"�������ϻ���ϰ", size = (800,650))

		icon1 = wx.Icon( name = "icon1.ico", type = wx.BITMAP_TYPE_ICO)
		self.SetIcon( icon1);

		self.menuBar = myMenu.initChineseMenu()
		self.SetMenuBar( self.menuBar )
		self.CreateStatusBar()

		self.Bind( wx.EVT_MENU, self.OnClose, id=wx.ID_EXIT )
		self.Bind( wx.EVT_MENU, self.OnModeDialog, id=201 )
		self.Bind( wx.EVT_MENU, self.OnModelessDialog, id=202)
		self.Bind( wx.EVT_MENU, self.OnFileDialog, id=203)
		self.Bind( wx.EVT_MENU_RANGE, self.OnChangeCursor, id=301, id2=303 )
		self.Bind( wx.EVT_MENU_RANGE, self.OnSetLanguage, id=401, id2=402 )
		self.Bind( wx.EVT_MENU, self.OnHelp, id=501 )
		self.Bind( wx.EVT_PAINT, self.OnPaint )

		self.bCheckBox      = [ False, False, False ]  #����ģʽ�Ի���λͼunchecked
		self.bRadioButton   = [ True, False, False ]   #������ģʽ�Ի���λͼѡ�����
		self.bLanguage      = True 					   # True means Zh, False means En
		self.cursorSelector = 0						   # 0 -> ARROW, 1 -> CROSS, 2 -> USER_DEFINED
		#create three bitmaps to show
		image = [ wx.Image( name="bmp1.bmp", type=wx.BITMAP_TYPE_BMP),
				  wx.Image( name="bmp2.bmp", type=wx.BITMAP_TYPE_BMP ),
				  wx.Image( name="bmp3.bmp", type=wx.BITMAP_TYPE_BMP )]
		self.bmp = [ image[0].ConvertToBitmap(), 
					 image[1].ConvertToBitmap(), 
					 image[2].ConvertToBitmap() ]


		self.cursorZhStr = [ wx.StaticText(self, -1, u"��ǰʹ�õĹ���ǣ�ARROW", pos=(50,30)),
					   	     wx.StaticText(self, -1, u"��ǰʹ�õĹ���ǣ�CROSS", pos=(50,30)),
					         wx.StaticText(self, -1, u"��ǰʹ�õĹ���ǣ��һ��Ĺ��", pos=(50,30)) ]
		self.cursorEnStr = [ wx.StaticText(self, -1, "The current cursor is: ARROW", pos=(50,30)),
						     wx.StaticText(self, -1, "The current cursor is: CROSS", pos=(50,30)),
						     wx.StaticText(self, -1, "The current cursor is: USER_DEFINED", pos=(50,30)) ]

	def OnModeDialog( self, evt ):
		mDialog = ModeDialog( self )
		val = mDialog.ShowModal()
		if val == wx.ID_OK :
			mDialog.GetParent().Refresh()
		elif val == wx.ID_CANCEL :
			mDialog.Destroy()


	def OnModelessDialog( self, evt ):
		mLessDlg = ModelessDialog( self )
		mLessDlg.Show() # use Show() when comes to modalLessDialog, it's a bool function

	def OnFileDialog( self, evt ):
		wildcard = "All fils(*.*)|*.*|" \
					"Python source(*.py)|*.py|" \
					"C++ source(*.cpp)|*.cpp"
		fileDlg = wx.FileDialog( None, "Choose a file", os.getcwd(), "", wildcard, wx.OPEN )
		if fileDlg.ShowModal() == wx.ID_OK:
			fileName = fileDlg.GetPath()
			wx.MessageBox( fileName ,u"ѡ����ļ���",wx.OK, self )

	def OnChangeCursor( self, evt):
		cursorSet = [ wx.StockCursor( wx.CURSOR_ARROW ),
					  wx.StockCursor( wx.CURSOR_CROSS ), 
					  wx.Cursor( "myCursor.cur", type = wx.BITMAP_TYPE_CUR ) ] 

		self.cursorSelector = evt.GetId() - 301
		changeCursor = cursorSet[ self.cursorSelector ]
		self.SetCursor( changeCursor )
		self.Refresh()

	def OnSetLanguage( self, evt ):
		langId = evt.GetId()
		if langId == 401:
			self.SetLabel( u"�������ϻ���ϰ" )
			self.menuBar = myMenu.initChineseMenu()
			self.SetMenuBar( self.menuBar )
			self.menuBar.Check( 301+self.cursorSelector, True )
			self.bLanguage = True
		else:
			self.SetLabel( "lab3" )
			self.menuBar = myMenu.initEnglishMenu()
			self.SetMenuBar( self.menuBar )
			self.menuBar.Check( 301+self.cursorSelector, True )
			self.bLanguage = False
		self.Refresh()

	def OnHelp( self, evt ):
		wx.MessageBox( u"�������ϻ���ϰ\n\n����:***\nѧ��:10***",
			"lab3", wx.OK | wx.ICON_INFORMATION, self )

	def OnPaint( self, evt ):
		dc = wx.PaintDC( self )
		cursorIdSet = [ 301, 302, 303 ]
		for eachCursor in cursorIdSet:
			# to get the selected cursor
			showStrId = self.menuBar.FindItemById( eachCursor )
			if showStrId.IsChecked():
				if self.bLanguage == True:
					self.cursorZhStr[ eachCursor-301 ].Show()
					self.cursorEnStr[ eachCursor-301 ].Hide()
				else:
					self.cursorEnStr[ eachCursor-301 ].Show()
					self.cursorZhStr[ eachCursor-301 ].Hide()
			else:
				self.cursorZhStr[ eachCursor-301 ].Hide()
				self.cursorEnStr[ eachCursor-301 ].Hide()

		for i in range(3):
			if self.bCheckBox[i] == True:
				dc.DrawBitmap( self.bmp[i], 50+i*200, 70+i*150 )
			if self.bRadioButton[i] == True:
				dc.DrawBitmap( self.bmp[i], 250, 100 )
 		


	def OnClose( self, evt ):
		self.Close()


class ModeDialog( wx.Dialog ):
	def __init__( self, parent ):
		wx.Dialog.__init__( self, parent, -1, u"��ѡ��ʾλͼѡ��",size=(300,250),pos=(350,400))
		bmpCheck =[ wx.CheckBox( self, 1001, u"��ѡλͼ1", pos=(50,30) ),
					wx.CheckBox( self, 1002, u"��ѡλͼ2", pos=(50,80) ),
					wx.CheckBox( self, 1003, u"��ѡλͼ3", pos=(50,130) ) ]
		okButton  = wx.Button(self, wx.ID_OK, u"ȷ��", pos=(150,60))
		cancelButton  = wx.Button(self, wx.ID_CANCEL, u"ȡ��", pos=(150,110))
		#���õ�ѡ��״̬
		self.bmpId = { 1001, 1002, 1003 }
		for eachBmp in self.bmpId:
			if self.GetParent().bCheckBox[ eachBmp-1001 ] == True:
				bmpCheck[ eachBmp-1001 ].SetValue( True )
			else:
				bmpCheck[ eachBmp-1001 ].SetValue( False )
			self.Bind( wx.EVT_CHECKBOX, self.OnModeShowBmp, id=eachBmp )
		#Ҳ����һ��Ҳ��Ч
		#self.Bind( wx.EVT_CHECKLISTBOX, self.onShowBmp, id=1001, id2=1003 ) 


	def OnModeShowBmp( self, evt ):
		checkId = evt.GetId()
		if self.GetParent().bCheckBox[ checkId-1001 ] == True:
			self.GetParent().bCheckBox[ checkId-1001 ] = False
		else:
			self.GetParent().bCheckBox[ checkId-1001 ] = True



class ModelessDialog( wx.Dialog ):
	def __init__( self, parent ):
		wx.Dialog.__init__( self, parent, -1, u"��ѡ��ʾλͼѡ��",size=(300,250), pos=(700,400))
		bmpRadio = [ wx.RadioButton( self, 2001, u"��ѡλͼ1", pos=(80,50) ),
					 wx.RadioButton( self, 2002, u"��ѡλͼ2", pos=(80,100) ),
					 wx.RadioButton( self, 2003, u"��ѡλͼ3", pos=(80,150) ) ]
		okButton  = wx.Button( self, wx.ID_OK, u"ȷ��", pos=(180,60) )
		cancelButton  = wx.Button( self, wx.ID_CANCEL, u"ȡ��", pos=(180,110) )
		self.bmpLessId = { 2001, 2002, 2003 }
		for eachBmp in self.bmpLessId:
			if self.GetParent().bRadioButton[ eachBmp-2001 ] ==True:
				bmpRadio[ eachBmp-2001 ].SetValue( True )
			else:
				bmpRadio[ eachBmp-2001 ].SetValue( False )
			self.Bind( wx.EVT_RADIOBUTTON, self.OnLessShowBmp, id=eachBmp )
		self.Bind( wx.EVT_BUTTON, self.OnOK, okButton )
		self.Bind( wx.EVT_BUTTON, self.OnCancel, cancelButton )

	def OnLessShowBmp( self, evt ):
		radioId = evt.GetId()
		if self.GetParent().bRadioButton[ radioId - 2001 ] == True:
			self.GetParent().bRadioButton[ radioId - 2001 ] = False
		else:
			self.GetParent().bRadioButton[ radioId - 2001 ] = True
		for eachBmp in self.bmpLessId:
			if not eachBmp == radioId:
				self.GetParent().bRadioButton[ eachBmp-2001 ] = False

	def OnOK( self, evt ):
		self.GetParent().Refresh()

	def OnCancel( self, evt ):
		self.Destroy()

if __name__ == '__main__':
	app = wx.PySimpleApp()
	frame = MyFrame()
	frame.Show(True)
	app.MainLoop()
