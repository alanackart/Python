from distutils.core import setup
import py2exe

setup(name="WorkHard",
      version="alpha",
      description="To be what you want to be!",
      author="AAEDWE",
      
      scripts=[r"c:\users\alan\desktop\multi-platform applications development\10142130257_lab2-2\10142130257_lab2-2.py"],
)
