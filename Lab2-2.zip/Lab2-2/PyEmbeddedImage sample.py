import wx
from wx.lib.embeddedimage import PyEmbeddedImage

icon1 = PyEmbeddedImage(
   "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAMRJ"
    "REFUWIXtl90NgCAMhItxKDdxRjdxK3wyIQbb6x+a6L1qjw84qpS6rJUYlX0r3HMiIsmD85mk"
    "wmx9A4Dbxm+sAKdZ8zKSdm2duAJnsXVwSSXLGBWUAaQZpQJk6gd4HEDVB6ziQqwGuJp5jzEM"
    "0JtFRA8RMxDRA1yt2GKq0bBTcAdsAvB8Fa+1JgBvLlqIoSvQ81ADRPzGt14wQG//IiBCT0E7"
    "MAoRBmANZgjA3eAIVHojkiDcAMgsX3EzSrkda4PXe/8AgCFYR0sXzHYAAAAASUVORK5CYII=")

class MainWindow(wx.Frame):
    def __init__(self, *args, **kwargs):
        wx.Frame.__init__(self, *args, **kwargs)
        self.SetIcon(icon1.GetIcon())
        self.panel = wx.Panel(self)
        self.Show()

app = wx.App(False)
win = MainWindow(None)
app.MainLoop()