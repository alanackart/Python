#!/usr/bin/python

"""
EditorPanel_DEMO.py

    The EditorPanel class in ths app demonstrates
    a complete and reusable text editor class.
    It can be used within any container control, 
    including a Frame, but is independent of
    that control for its operation.

Ray Pasco   pascor(at)verizon(dot)net
        1.0     2012-05-04

Based on:
    "Another Tutorial", Njan Bodnar 2005-2006
    http://code.google.com/p/hltdi-l3/source/browse/PhraseAlignTool/example_editor.py?spec=svncb25b316c69f33df8f8c2805e263665d39fbb306&r=8f996c4f2e04c01b01f37257042bb6a6654e8fcb
"""

import os, sys

import wx

#------------------------------------------------------------------------------
#==============================================================================
#------------------------------------------------------------------------------

class AppFrame( wx.Frame ) :

    def __init__( self, editorLabel=None, DEBUG=False ) :
        
        wx.Frame.__init__( self, parent=None, id=-1, pos=(250, 0), title='EditorPanel class demo' )
        self.SetClientSize( (700, 400) )
        
        #-----
        
        self.frmPanel = wx.Panel( self, -1 )    # So the Frame appears the same on all platforms.
        self.frmPanel.SetBackgroundColour( (211, 218, 237) )
        
        #-----
        
        self.edPanel = EditorPanel( self.frmPanel, label=editorLabel, DEBUG=DEBUG )
        # For the Frame's "X" close button or pressing <Alt-F4>.
        self.Bind( wx.EVT_CLOSE, self.edPanel.QuitApplication )     
        
        #-----
        
        # There's no need to make this panel a stand-alone class 
        #   since it's very application-specific.
        self.controlsPanel = self.RightSidePanel( self.frmPanel )
        
        #-----
        
        frmPanelSizer = wx.BoxSizer( wx.HORIZONTAL )
        
        frmPanelSizer.Add( self.edPanel,       proportion=1, flag=wx.EXPAND )
        frmPanelSizer.Add( self.controlsPanel, proportion=0, flag=wx.EXPAND )
        self.frmPanel.SetSizer( frmPanelSizer )
        
        self.frmPanel.Layout()
        
        #-----
        
        if DEBUG :              # Only for development and demo purposes.
            self.SetFocus()     # De-select edPanels' textCtrl's initial test text.
        self.Show()
        
    #end def __init__
    
    #----------------------------------
    
    class RightSidePanel( wx.Panel ) :
        """ A very basic panel to show that the container holding EditorPanel can be shared
        with all other controls. In a real app this panel could hold all the controls
        for the user to control the app other than directly manipulating the editor.
        """
        
        def __init__( self, parent=-1, size=(300, -1) ) :
            
            # Create a simple container widget to hold the editor textCtrl and its header staticText.
            wx.Panel.__init__( self, parent=parent, id=-1, size=size )
            self.SetBackgroundColour( (230, 250, 230) )     # Color of toolbar bottom edge.
            
            infoBtnID = wx.NewId()
            infoBtn = wx.BitmapButton( self, infoBtnID, bitmap=Info_32_PNG.GetBitmap() )
            infoBtn.Bind( wx.EVT_BUTTON, self.OnAppInfo )
            
            # Have a little fun randomly varying the sizer's control
            #  of the butoon's vertical position within this panel.
            import random
            CENTER_BUTTON_IN_PANEL = random.randint( 0, 1 )
            if CENTER_BUTTON_IN_PANEL :
                # Position the button within the exact center of the panel client area.
                rsPanel_innerSizer = wx.BoxSizer( wx.VERTICAL )
            else :
                # Place the button "border" distance from the top, 
                #   centered along the sizer's minor axis, wx.HORIZONTAL
                rsPanel_innerSizer = wx.BoxSizer( wx.HORIZONTAL )
            
            rsPanel_innerSizer.AddStretchSpacer( prop=1 )
            # Must NOT use wx.ALIGH_CENTER flag when adding the button !
            rsPanel_innerSizer.Add( infoBtn, proportion=0, flag=wx.ALL, border=135 )
            rsPanel_innerSizer.AddStretchSpacer( prop=1 )
            
            self.SetSizer( rsPanel_innerSizer )
            self.Layout()
            
        #end __init__
        
        #----------------------------------
    
        def OnAppInfo( self, event ) :

            msg = """\
            The EditorPanel class in ths app demonstrates
            a complete and reusable text editor class.
            It can be used within any container control, 
            including a Frame, but is independent of
            that control for its operation.

            """
            dlg = wx.MessageDialog( self, msg, 'EditorPanel Info', wx.OK )

            result = dlg.ShowModal()
            dlg.Destroy()
        
    #end class
    
#end AppFrame class

#------------------------------------------------------------------------------
#==============================================================================
#------------------------------------------------------------------------------

class EditorPanel( wx.Panel ) :

    def __init__( self, parent=-1, label='', DEBUG=False ) :
        
        # Create a simple container widget to hold the editor textCtrl and its header staticText.
        wx.Panel.__init__( self, parent=parent, id=-1, style=wx.RAISED_BORDER )
        self.SetBackgroundColour( (224, 229, 245) )     # Color of toolbar bottom edge.
        
        #-----
        
        self.iconToolbar = self.CreateIconToolbar()
        
        #-----  EDITOR STATE VARS
        
        self.editorTextIsDirty = False
        self.edLastFilenameSaved = ''
        self.fileOpenDir = os.getcwd()
        self.edOverwriteMode = False        # For future overwrite-mode implementation.
        
        initialEdText =  \
        """\
The EditorPanel class in ths app demonstrates
a complete and reusable text editor class.
It can be used within any container control, 
including a Frame, but is independent of
that control for its operation.

"""
        if label :      # Editor title/description text
            edLabel = wx.StaticText( self, -1, label=' '+label, style=wx.RAISED_BORDER )
            edLabelFont = edLabel.GetFont()   # Enbolden (?) the font.
            edLabelFont.SetWeight( wx.BOLD )
            edLabelPointSize = edLabelFont.GetPointSize()   # Enlarge the default font
            edLabelFont.SetPointSize( edLabelPointSize + 3 )
            edLabel.SetFont( edLabelFont )
        
        # Editor textCtrl
        edTxtCtrlID = wx.NewId()
        edTxtCtrlStyle = wx.TE_MULTILINE | wx.TE_PROCESS_ENTER | wx.TE_DONTWRAP
        self.edTextCtrl = wx.TextCtrl( self, edTxtCtrlID, style=edTxtCtrlStyle )
        self.edTextCtrl.SetBackgroundColour( wx.WHITE )
        
        edTxtFont = self.edTextCtrl.GetFont()
        edTxtPointSize = edTxtFont.GetPointSize()
        edTxtFont.SetPointSize( edTxtPointSize + 2 )    # Enlarge the default font
        self.edTextCtrl.SetFont( edTxtFont )
        
        if DEBUG :      # Only for development and demo purposes.
            # Add lots of initial text to make sure the vert scrollbar is shown.
            for ctr in range( 5 ) :     
                self.edTextCtrl.AppendText( initialEdText )
            self.editorTextIsDirty = False      # Would normally be set True for additions.
        
        self.Bind( wx.EVT_TEXT,     self.OnTextChanged, id=edTxtCtrlID )
        self.Bind( wx.EVT_KEY_DOWN, self.OnKeyDown,     id=edTxtCtrlID )
        
        #-----
        
        edPanelSizer = wx.BoxSizer( wx.VERTICAL )    # Positions the staticText & textCtrl
        
        if label :     # Include in the sizer only if defined.
            edPanelSizer.Add( edLabel,      proportion=0, flag=wx.EXPAND )
        
        edPanelSizer.Add( self.iconToolbar, proportion=0, flag=wx.EXPAND )
        
        edPanelSizer.Add( self.edTextCtrl,  proportion=1, flag=wx.EXPAND )
        
        self.SetSizer( edPanelSizer )    # Associate the sizer to container control
        
        #-----
        
    #end __init__
    
    #----------------------------------
    
    def CreateIconToolbar( self ) :
    
        toolbar = wx.ToolBar( self, -1 )
        
        # Open file
        openFileID = wx.NewId()
        tool = toolbar.AddLabelTool( openFileID, label='Open File', 
                                     bitmap=Open_32_PNG.GetBitmap() )
        self.Bind( wx.EVT_TOOL, self.OnOpenFile, id=openFileID )
        
        toolbar.AddSeparator()
        
        # COPY
        copySelectedID = wx.NewId()
        tool = toolbar.AddLabelTool( copySelectedID, label='Copy', 
                                     bitmap=Copy_32_PNG.GetBitmap() )
        self.Bind( wx.EVT_TOOL, self.OnCopy, id=copySelectedID )
        
        # CUT
        cutSelectedID = wx.NewId()
        tool = toolbar.AddLabelTool( cutSelectedID, label='Cut', 
                                     bitmap=Cut_32_PNG.GetBitmap() )
        self.Bind( wx.EVT_TOOL, self.OnCut, id=cutSelectedID )
        #Open_32_PNG.GetBitmap().SaveFile( 'Open-32.PNG', wx.BITMAP_TYPE_PNG )
        
        # PASTE any text previously copied text
        pasteID = wx.NewId()
        tool = toolbar.AddLabelTool( pasteID, label='Paste', 
                                     bitmap=Paste_32_PNG.GetBitmap() )
        self.Bind( wx.EVT_TOOL, self.OnPaste, id=pasteID )
        
        toolbar.AddSeparator()
        
        # SAVE TO FILE editor's current text
        saveFileID = wx.NewId()
        tool = toolbar.AddLabelTool( saveFileID, label='Save', 
                                     bitmap=Save_32_PNG.GetBitmap() )
        self.Bind( wx.EVT_TOOL, self.OnSaveFile, id=saveFileID )
        #Save_32_PNG.GetBitmap().SaveFile( 'Save-32.PNG', wx.BITMAP_TYPE_PNG )
        
        # EXIT this app.
        exitAppID = wx.NewId()
        tool = toolbar.AddLabelTool( exitAppID, label='Exit', 
                                     bitmap=Exit_32_PNG.GetBitmap() )
        tool.SetLabel( 'Exit' )
        self.Bind( wx.EVT_TOOL, self.QuitApplication, id=exitAppID )
        
        toolbar.Realize()
        
        return toolbar
        
    #end CreateIconToolbar def
    
    #----------------------------------
    
    def OnTextChanged( self, event ) :
        
        self.editorTextIsDirty = True
        
        event.Skip()        # ???  What other handler would care ?
        
    #end def
    
    #----------------------------------
    
    def OnKeyDown( self, event ) :
        
        keycode = event.GetKeyCode()
        if keycode == wx.WXK_INSERT:
            
            pass    # Overwrite mode is not implemented yet.
            
            """
            if not self.edOverwriteMode:
                self.edOverwriteMode = True
                # Insert code here to implement text overwriting...
                
            else:
                self.edOverwriteMode = False
            #end if
            """
            
        #end if
        
        event.Skip()
        
    #end OnKeyDown def
    
    #----------------------------------
    
    def OnOpenFile( self, event ) :
    
        wildcardStr = 'All files ( * )|*'
        
        fileOpenDlg = wx.FileDialog( self, message='Choose a file to open', 
                                     defaultDir=self.fileOpenDir, defaultFile='', 
                                     wildcard=wildcardStr, style=wx.OPEN|wx.CHANGE_DIR )
            
        if (fileOpenDlg.ShowModal() == wx.ID_OK) :
            
            filePathname = fileOpenDlg.GetPath()

            try:
                file = open( filePathname, 'r' )
                text = file.read()
                file.close()
                
                self.edTextCtrl.AppendText( text )            
                self.editorTextIsDirty = True
                
                self.fileOpenDir, unusedBaseName = os.path.split( filePathname )
                
            except IOError, error:
                dlg = wx.MessageDialog( self, 'Error opening file\n' + str( error ) )
                dlg.ShowModal()
                
            except UnicodeDecodeError, error:
                dlg = wx.MessageDialog( self, 'Error opening file\n' + str( error ) )
                dlg.ShowModal()
            #end try
            
        #end if
        
        fileOpenDlg.Destroy()
        
    #end DoOpenFile def

    #----------------------------------
        
    def QuitApplication( self, event ) :
        """ Ask to save to a file since there were modifications. """
    
        if self.editorTextIsDirty :
            
            dlg = wx.MessageDialog( self, 'Save before Exit?', '', 
                                    wx.YES_NO | wx.YES_DEFAULT | wx.CANCEL | wx.ICON_QUESTION )
            val = dlg.ShowModal()
            if (val == wx.ID_YES) :
            
                self.OnSaveFile( event )
                if not self.editorTextIsDirty :
                    wx.Exit()   # Exit wx.App.MainLoop()
                    #-----
                
            elif val == wx.ID_CANCEL:
                dlg.Destroy()
            else:
                wx.Exit()   # Exit wx.App.MainLoop()
            #end if
        else:
            wx.Exit()   # Exit wx.App.MainLoop()
        #end if
        
    #end QuitApplication def
    
    #----------------------------------
        
    def OnSaveFile( self, event ) :
    
        if self.edLastFilenameSaved:

            try:
                file = open( self.edLastFilenameSaved, 'w' )
                text = self.edTextCtrl.GetValue()
                file.write( text )
                file.close()
                
                self.statusbar.SetStatusText( os.path.basename( self.edLastFilenameSaved ) + ' saved', 0 )
                self.editorTextIsDirty = False

            except IOError, error:
                dlg = wx.MessageDialog( self, 'Error saving file\n' + str( error ) )
                dlg.ShowModal()
            #end try
            
        else:
            self.OnSaveAsFile( event )
        #end if

    #end OnSaveFile def

    #----------------------------------
        
    def OnSaveAsFile( self, event ) :
        
        dir = os.getcwd()
        
        wildcardStr = 'All files|*'
        save_dlg = wx.FileDialog( self, message='Save file As...', defaultDir=dir, defaultFile='', 
                                  wildcard=wildcardStr, style=wx.SAVE | wx.OVERWRITE_PROMPT )
            
        if save_dlg.ShowModal() == wx.ID_OK:
            
            path = save_dlg.GetPath()

            try:
                file = open( path, 'w' )
                text = self.edTextCtrl.GetValue()
                file.write( text )
                file.close()
                
                self.edLastFilenameSaved = os.path.basename( path )
                #self.statusbar.SetStatusText( self.edLastFilenameSaved + ' saved', 0 )
                self.editorTextIsDirty = False
                #self.statusbar.SetStatusText( '', 1 )

            except IOError, error:
                dlg = wx.MessageDialog( self, 'Error saving file\n' + str( error ) )
                dlg.ShowModal()
            #end try
            
        #end if
        
        save_dlg.Destroy()

    #end OnSaveAsFile def

    #----------------------------------
        
    def OnCut( self, event ) :
        self.edTextCtrl.Cut()
        self.editorTextIsDirty = True

    def OnCopy( self, event ) :     # A "meta-edit" ?
        self.edTextCtrl.Copy()

    def OnPaste( self, event ) :
        self.edTextCtrl.Paste()
        self.editorTextIsDirty = True

    def OnDelete( self, event ) :
    
        frm, to = self.edTextCtrl.GetSelection()
        self.edTextCtrl.Remove( frm, to )
        self.editorTextIsDirty = True
        
#end EditorPanel Class

#---------------------------------------------------------------------

# This file was generated by Image2PyFile.py

from wx.lib.embeddedimage import PyEmbeddedImage

#----------------------------

Open_32_PNG = PyEmbeddedImage( 
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAmVJ"
    "REFUWIXNlz1v00AYx3/xS+zYCVBYKKqgJROqOhQJmgGWKmtHhIRg7gfgC+QL8AGYg0DM7Cyl"
    "EmFAYmIKQgxVqVQhoSbn89kxQ+LKTRzntQn/LM7d+f4/3XPP47tcTtNZprTLmHS3Xol265Vo"
    "nLG5/hV4XXuc+eJ+7SA3yjz5/+OLz5njjbTG58/unz+/efu1v+2CQRIoNtfvtgAIf7js1itR"
    "FkTqCiQBhkAM9L0vKwBuPXRoizYATsHh6Ev3eRjEWHsgNo7N+vti883qKkXHpeSWKLklio7L"
    "ZnUVGAzNRABZEHuNBgBb1TUs06Jg2biOg+s4FCwby7TYqq4NhZgoC/pDEJtvPLgOYUQURuia"
    "jp23sPMWuqYThRGEUXdMCsTUaRibr6wbBFIh2h6+VHSCDlrv1wk6+L2+QCpW1o0BiNQsGEfF"
    "fJEz/4w/PwNOjFM6RojlFbj36CamZQKgpOL7p2OkLdACHTPIn787M8C77c2Btr1GA9uxCFSA"
    "lAopJACHT74NTcOpAYbJlwrpSaTw8Tw5cvyllOJJNPcVEC2B11uB02YwXSmeRnuNBne2r9Ju"
    "CTzPRwp/rOmXHoKlA8wlBHFRarcE0vNRvkIcm4sBiM1vlI1uxVMB3u9uwRm1AWHGEMTm1zY0"
    "hPBQvjo3f9ocbwVm/hZcuQ1SSNpHBvLEAuDDzg7QPVuMOmFNFIK088DfXwDmBWPIPkNMDZCc"
    "OGmWpkL5FaL5cuR8S0/D/xsgp9uLB9ivHeTijROF3uIB+iGm1TgbEDKyoHfhGHpHmJcy0zAN"
    "YtTVbK4ASYh5miY1cDVbtP4BMBQL9l9YAsoAAAAASUVORK5CYII="
    )
GetBitmap_Open_32_PNG = Open_32_PNG.GetBitmap

#----------------------------

Copy_32_PNG = PyEmbeddedImage( 
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAbNJ"
    "REFUWIXtl09Kw0AUh38vSWMluBG6kBpc9ADiwkN4GXsQQaibLnoTD+EF1FWoQgV3LlKTPjfO"
    "OCbzL5NAF/ogtAnNm+998yaTEkUx9hmJ+MK7mrvcSFFMgwIAALMfAxGBdzUPAZE0LxDZcwpI"
    "ZgYR9YZoAfhaGAoi2MBQEL0MDAERbED3u5DGDDJg+o0LXheRLol6iLi4ecB0UXQewBUknoS8"
    "q9lU2cndKyKukKQxqm2N9TyXsF6DWKbFagAArm7vkY4Y2WyCg/wYSRpLE8zsPERxvQxMFwWy"
    "2USel8W7l4nv1SE/dSZaAM1kAsoFYa6Qfq2cJkRrCnQKAWA9z/Hx/CbPm9MhB7D0BTO3psO5"
    "CtSkLggV+nL16AXhNOBr4mz5Iq+dL5+wqTJjUcBPYzp7QAcI6HsCAKptjaj8RDlOsbk+NeYR"
    "/eBtwMcEACRpjOhojLiqtdU3C/TuAfVmW0+ISA9HxoKsAL4GVBNqqBCdDbiq1yXQ7Q8qhKsI"
    "uRt22UZFB4vB1WlohnbbViAo5LXc9tj2DbEKWu8DXZOEhArfC6Cvhd4A/wb+toHQ6tt59vz3"
    "/AuRMXpI0l6G7wAAAABJRU5ErkJggg=="
    )
GetBitmap_Copy_32_PNG = Copy_32_PNG.GetBitmap

#----------------------------

Cut_32_PNG = PyEmbeddedImage( 
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAZRJ"
    "REFUWIXFVTFOxDAQXCO4GgnxhiBa/nEdruKCNogKUSFKKoTorkMUvsrNSeEBvABR3yvoD4ml"
    "II4Wx07WiWNGsmQnjne8O7MBmIjzi6tjstRksLA3lQAhoQEAELFMcSYDZwdkoQFAYwPIk4H3"
    "L7oae/MUJWDfdg4CnboLIdY5CYRSr7IRoIi9/VQC3to/vWzuchHI6XkvWt9T/yOiiDkkmQZo"
    "/RFRGGMWnO/2UxFooIRoE7AzxiyklDtnzx/tJHWBD5u3j0NwflKIWFr90AzooqqDotqulmuI"
    "8DcAgJTy2c5dwdqS2Xz1Bg+Q0JwO6HMK2ft7VlHVWFR1319Mkz3tM0f9LDQx9PX9wylAV4Sh"
    "FCsAKC1Z9zacfuBkSD3e3oCPQBQ4wd3A7nuXgPZtAlKa7WrZ+qyoajy5fLXa6ENQvFNE2JaD"
    "koqF7QNq6BauA6gWBgTcizHMg9ka0yuiEbCsz6YsTGnFKjDPRiAJOASOmvFvBGYFh8BnM1zo"
    "wDwKHBtakt82WEobju1gHRJz94DRrXYIP3Eu9Jfu15GbAAAAAElFTkSuQmCC"
    )
GetBitmap_Cut_32_PNG = Cut_32_PNG.GetBitmap

#----------------------------

Paste_32_PNG = PyEmbeddedImage( 
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAgJJ"
    "REFUWIXNl71Lw0AYxp9La9oiLkIHKV1crVgHB0cXwUEoGUqp/gciBUehU8BFECoVB1ctoUNQ"
    "HASXjm6iaCc/llKECl1EFG0bh5JwTXPJ5aPUBwLJm9z7/vJc7iOECCGMU2HeB0/PKhrr3uZG"
    "nowcAADy2exQrFKteq3tHkAvls9mfRdmAmytpyytvlH2AADLud2hGKvN0eWjY9dYOrAyP2uc"
    "f8/lmI1pGACI1hXjvPbw6lSbDWBWPjfc9+ZYRfHWJYKnVgHK0YFoXUFFcXpq0P5AAfwkDwyA"
    "Fu/HFSiAJKsAALUoAQDKF/e8+S2HJxFCxvB0BJBkFYv7t2iJcTRlFbVMup9ZY87MtiJkcGqw"
    "BZBkFTOHbxDEOMJiCIlSA83zO5SpJOaEdrKCZgJIsoq1g2uIsRQiyXg/2GgjUWoMJPLqhC7m"
    "PKAWJVztrKLz0zVikeS04YQuQgj34QpAh2gWkvh8eWdCaJrGfbgG4IVgybcDvBBmkKWTJwDD"
    "7ngGcIKg3Vg4fkarMwkgQAecIAAYEO0PAV+/PQABO6BrO5O2hRCmogh1+iMncAd0EUKYEAAg"
    "xiYAjMgBWs1CcuCahtBBR+KALqthSEPwOOB6OTYXp7vBLPNbu1oLnGS230o864QlgJtNh9/V"
    "kHj5N9R6Xc3PfoDekPz/XTFLbqy3zzPm3/M/wVYENaoecsEAAAAASUVORK5CYII="
    )
GetBitmap_Paste_32_PNG = Paste_32_PNG.GetBitmap

#----------------------------

Save_32_PNG = PyEmbeddedImage( 
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAj9J"
    "REFUWIXNls1u00AUhT/P2I7HkVBThFJ1gVKKilSEhNgSiQXZ8Arta3WTByBPEXbpBhYsEEJC"
    "ggQWJQKRQOrE8V/NokpIwHX+nLR3ZY/GPp/PmTtjqtWqUa1WDa6p9NFFqVCI1yHQ6na1VADT"
    "NOXoptnpZCq+t709c47IVHGJ0pMG5yGfVfO6mQiQdRRpdTMjgOVjWNS9KwE2FcPNjQA2E0Mq"
    "wCZi0IvF4lq24LkBkgYXtX4Vp659I0pdA2lVqZX/G6sfNbIBmBXBpEO37kLgB7htYwy1CMjS"
    "EdSPGlRqZXpfYWsvh7brE4UR3vcclVp5bgjhOE7sOM5SnTAS+dW8QCkLwzSwij6QHFFSrdwF"
    "zU6HSq3Mz08hdw4svKGPtnMZyf7JIa3j08UBFu2CURx2XiGlYCgF7Pi47dlrPNOz4Mvb39h5"
    "hZ23sPMWAM9fPk2NN7OzYBSFyiuEFEghEQcePz76qc9lfhaYOQMhNISUCCmAdIDxL3OpUIgX"
    "FUxa6U9elCCGMIgIvIAPjTae5SJCiRGa43mvjk81WKELJmFvP5bYlo2yLIIwQNd1dEMihMbD"
    "Z7t4Qw/P9XF6Lt1WOPWelRyAvy5sPQJb2aichZXLYegGQhPEUUwYhDiOS/NNZ+rrIYMuGG9G"
    "76DnnHM+6NN3Bwx9j+giQpMaSC1RHP5xYBWQ/ZNDANQDH1upcSSGrvO+/i1RfAogixr1vHnf"
    "vYRQNmevB1eKZw4wCSHv9Yk+51PF1wIQx3E82Z5p4gB/AF8v6tam65qxAAAAAElFTkSuQmCC"
    )
GetBitmap_Save_32_PNG = Save_32_PNG.GetBitmap

#----------------------------

Exit_32_PNG = PyEmbeddedImage( 
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAABatJ"
    "REFUWIXFl3+IXFcVxz/n3Pvmvc7u7GR2M901W6W0K9JutmNMEwJW0xakSAVFVPxPgoIRsf6n"
    "aCP+KME/xD8jSguR1KZ/SUURSm2lLU1KGpI6S2sK2exuadwf7uzMJk1mZufHu/5xX2Z26ySZ"
    "TREPHO57j/vu+Z7f58L/maTfjYW9+64G1oJzOOeIcTgHLnkHEBFUlbjdph23e0oTEXCCOGrT"
    "Z97YbvsFMJrfnn7m6FOUVkosLi+ytlahXC6zslKiVFphdXWVkeHt7N69m7/+5XlOvnkKG2r3"
    "AAdihdRtBuMiXNOmAfoGULhviuHhYay1pMKAkZHt7NhRpVqtsrZW4e23/0ljvUEYhojAwsIs"
    "Q6NhYmIhbjmCtJLLR9jmGHHLVLcEIAgCRBUbBIRRROzAGEsYhkRRSLPZplarkR4YxCG42CEd"
    "DyeriH92Xc/3DcD/b4iBRr1Oo9Fgfb3O+nqden2dbHYbY2NjZDIZcrkcIoKI4ABBEPHrRuEA"
    "2lNSD2pmMlvBytBYSOxifKTS5Q9Q3wDS8/Ncnp2h3W5jBgb8wQnFcUyr1UJVyWQGuWN8fLNA"
    "3cC3CuCh48d58/69VBcXCfP5TuptJOcccRx7F6h4NoIxJmFFVX0qbhUAwLlKhenHvs+Vs2cZ"
    "3DkFcbzJEtdqQpAKUKMJJ8JtwsbHwy0BOFgosPC3Fyn+6HGunHiNYHwcjSLazSZhGJLP5xkd"
    "HSUVBKh6ba01GKsYa7DWoMZsArClLIiBbxYKPPXS3zlfrXHHLw/DUIYom+W+e+7p7Gs0mxhr"
    "vIZGMcagAsb4SrmxAG/JAhpFAHyrUGD59GkWf/w4reV/k5+YAGBq6pPs2nV/IlgS9q4wgaJW"
    "EfMhAKAKYQjAtycnuXjydZaeOIydmwPg4sWLzM/PA2BTik0pQWgIIkMQWs8p9cGZYLAAL+dy"
    "PTK0B5XLEARgvHm/Uyhw9ORJ3vnpz8g/e5xKpQTAc3/8M0HkvWsDi7UGYsGEgkkp7Q1qd2Jg"
    "/8Td3YiON+BR9SX08mW4ehWyWf9uLTSbHCgUOPr8C7zwuUe469e/YsfkTrCpLoAk+JwDkxKM"
    "vV4l9L31v7ndhlbLmz6b9do757+p//1AoUC5OM2lJw7TWFrCDWVJ3aaeIyWIbMIGkzKI9uoF"
    "G3M67lUz1QuP4+63VgsaDeoiHLz3Xp598SVqX/0aK5/ahwm8m4wxGDXg/O9qXBKD8gEAN6Nr"
    "FulrL51qJ5JURAQ1oLL5jK4LVG/M0mN4shaiiCgM+c1bb5H97AN8/OljDH/pi6gFtSDJqgGY"
    "AIzlOqVY5Oa8kYKg447fF4tsm9rJwA9/ACMjxOVKB4C5tqYETQlqBemVBa/MXLipZfffead3"
    "QxRBrdYRrnv2MPDdg9iJCYa35UgbiyYni8Gb3iTa2+5c0gHwYKVy0+H05VzOYYyPpET4kWKR"
    "/L69fPTQIaIHPo3OvsulpVXWyrWOlps9qahujoEt9QKcg3odgCfPneOu/Z8h95NDZCZ34uYX"
    "WKlUeP3Ma0zP/ANj/NHGmE5jEpHOjHhLAFyrhQC/Kxb52EMPMnnkCK2hQd6bnePC9HneXZrh"
    "ndVTlFr/IkgHiQXU9wRNSrDGmy4DW5sJgWPFInd/5ct84tDPuTRwO8vnzvPqmecozp2i0Whw"
    "hRIStgnsAFb8ICsqqAhiYuTDuODpYpHbH/48Iwce4w3qnD72C96//D6zl6Ypt95jMJ1lMBjE"
    "mgBV6VxErpldRBAnqOumQd8AZtoxuT27iL/3dV69eoETTz5DSeYwxhAOhXxEx8GAivoo72jq"
    "usO5JjXgVlxw5uFH+MI3HuV8s8WJ2d/SzFUZ1CC5jjlUWpAM4YnCHeoY3QDiQMOO6L4BnG03"
    "SS38qd/tN6RaWSFma1ez2vJi9ZU/KHHcxDmHSJob322v3zdcLEhMrW/E/0v6D2nb6JESJEFI"
    "AAAAAElFTkSuQmCC"
    )
GetBitmap_Exit_32_PNG = Exit_32_PNG.GetBitmap

#----------------------------

Info_32_PNG = PyEmbeddedImage( 
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAACAJJ"
    "REFUWIXFl1tslMcVx38z32XXa69va8BAwTENwcaI3EouJQ6gEkAQKVRVm4emUlGbPqRq1VZV"
    "nwJ9aBQpqhop6lMbpUmbKoSiKIFaRICJIbdCisElThywEy6xAzjGBu/lu85MH3a9XgeSkIeq"
    "Rxp9M9/3zZz/+Z8z58wIIS3+n2Jf74+nB0+ZXC6HVyh87j9VqRRSSmpra1nQukhcz7riyxgY"
    "HHjfTIyPU1dfz+K2tusC+25fH77n0dzcTMuNi78QyBcCOPLG6yZVU0PH8uUz3r/8xBPE4+MY"
    "38cA2nVRtbU8tHUrBpgE6oB/Hz6MBFasvOdzQVwTwNiF82bgvfdoW7aMTFMTx/v7GXzlFeKB"
    "AVIFj7Rjk0wksBwHtCb2fbL5PBdzOcZcB7FkCb/4w1NYjmRoaIiRM2dYs37DNUFcBeDSxQvm"
    "vf5+7lm9umjt00+T37uXeVqTbmxEuS5KSrRS6ChC+T4q8JFK4wLK8zjvBUw01PCTv23HTlfz"
    "yegoHxw/ztqNm64CcRWAN147YFauWgXAC9u2kT56lObmZsJUCoPBxBodheggQCtFYXiYyPcR"
    "WpOYNQu0JgwCbMvGS6T49o4XsGvTnB0Z4dwHH7Bq3XrxuQCO/utt07JoEZmmJnZs20ZDby/1"
    "C1sIbAvCsGhxEKLjEBPF+GNjNN19NwvXreOTw4c5t2MHTroOHUegDbZtM6kMD/Z0Y1Wn6Ovr"
    "wwaW3/4NcRWA4bNnzOUrV1ja0cHeZ59F79xJY+siAhVjwhDlh2gVYmKFDkJiL4/bmOG+nTvL"
    "BvRs2cLFffuwM7MBBbHGTlhcUpIfvvMWVjLFwe5ubr71VjKz5wgAOTV5dHSUpR0dAOS6umho"
    "bsYr5Imzk0T5LMovoPwA5fvEUUSUy4OUmAo6rVQKf3ISHfko3yfyC3iXJkjlJ/h9x3K0Uqxe"
    "u5bTH31UniMBzg9/bGqqqwHoevxx6j2Pgu8TZbPEno/yQ+KgqFz5Ptr3ELbNRO8xjj72GFcG"
    "B+l/5hmGd+0i0dRUBqr8gNgP8Ccmqbs8zu++tR6AQkUyE0JaDPS/a5a0twPw9wceYCHgS4lR"
    "Ch3H0884RiuFKb2LPY/86dNoY9C+T/X8+ZBIoH0fFUaYKMKoGOIIwpizrs1vCx69/f3UOQ43"
    "Le0QM1Lxwe3bESMjhHPnoCIzQ+EUEKM1KpsjNzKMMQanoYGqpiZwHHJnz6KzWYgidAwIjVEK"
    "K9bYQpEOinpuX7aMvmPHgFItsB0HgOzASVIIfL8ACozS6CiqYCAizBeonj+fO7c+SiKToWrh"
    "Qua2t3NgyxY+6u0lbcCyAC2RQmMbgwSEgYyJ+eOaNfysp4cwiioA2EUi1OgFhJQYL0Rrg1Yx"
    "Jp5iIMJExf6VkycZO3KEzqeeKrM3sns3rjE4gFQgUEgDFiBKwZYE8iMjRV1aTwehnUwyEYWo"
    "bA4Ta2IvRAX+dNQHBXQ+T1woEExOcuHiRQaff76sfLCri8vj46QBp2SVc42+C7i5XDH4Sqzb"
    "AFopQGDFEZEKEMpgtELHCh2HqCgi9jx0IUfghcTAkocfLgO4+OqrmJICWWqioj/VbMAVxRyk"
    "SwzYAGEQUG/b4LiobB6kKPo/VqiguO2iMEKFIRJIA1+7//4ygLE9e6guLSYo0j4FonJsI7DT"
    "6aILwnAaQBSGgMBprCdb8BAWYDTaD1FBgAojhIpwDfjAnHnzaOnsLPr+nXeYPHOGmpKiKWWf"
    "ZUEAljBYCxYAYJWYkFMuEALS7R14KkKHIcrz0LkChD5WHOOYoh8NMG/Tpmnr9+4lBFwx7XOr"
    "wvdTYxdQBh7cvx+AhOtOA3BKgwUbNkAiifIDTD6PViEy1liY8kJVwNyNG6f9v307NUJQVVeP"
    "XaF4CoRdUp5EEpbm7Dl0iIbGxmkAs2bN4nhvL62tN9C4ehUm4YABR89cUANNmQyLNm8GYLin"
    "h9zAAMu2bsVJp5HMjPzyUwgc1yEonTHsQoEbb1oyXYwaM01CWsWquPmvf0G4CWzLxbLljIWM"
    "gNlr15atd2yb5c89R3DqFN7HH5OosLrsCilIuhZZV/Cdnh7++fbbzJ4zp7xGuRq2tLTw1uuv"
    "Y1sO8x75KbqmBlvaWMIqJhegygi8oaHy5DmdnQT9/Xzy4ovlXVDZXAFJWyJsh7EfbAFAjI5y"
    "24o7rj4PALz/7gmTDwJuu+UWXvr+Q5juAySyVxBhgNQGC0GEIbNiBQ0338ylA91Mnj5DNdMZ"
    "r3LbuUJiuQ4Da+7lu6/u4+Vdu1je0cHiJW3XBgDw1qGDpm7uXJa23sArP/4Rons/iUuXkYGH"
    "UMW8HgJaQNJIEuhrbrsaS+IJwan1G/heVxe7u7tpTqW4q/PeGUcyyWdk5arVYuzcOU4Mfcj9"
    "f/ozqUd+jmltxUrVUiWKEV0N1BmowmALsCXYpW81lqRGCkYtm1O//FVR+f79NEh5lfJrMjAl"
    "b/S8ZqTrctedK4iuZDn4m18Tv/Qy1ePjJC2JSCSQjo0QYCmBiGO0Dsklq5i8bwObdv4DgF27"
    "dzO7sZGVq1Zf37G8Uk70HTefnj/PmnX3YUpnr+4nn4S+/5AY/ZQkMQKJchwK9XX4be1sfPRR"
    "ALrefBMxNsaNbW20dyz7aheTShkf+9R8ODREIZ+ns7SPAUysIdIICdo2SKtYCfYcPIjteTRm"
    "Mtxx9ze/9H74pQAqZejUSZPLZgnCEE2xphtjkEKA1iSTSerr6/n64puu62L6lQH8L+S/rprk"
    "8jjZs4gAAAAASUVORK5CYII="
    )
GetBitmap_Info_32_PNG = Info_32_PNG.GetBitmap

#==============================================================================

def Main() :
    
    app = wx.App( redirect=False )
    appFrame = AppFrame( editorLabel='Text Editor with an Icon Toolbar', 
                         DEBUG=True )
    app.MainLoop()
    
if __name__ == '__main__' :
    
    Main()
