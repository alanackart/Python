import wx


class MainFrame(wx.Frame):
    def __init__(self, iid=-1, redirect=True, parent=None, pos=wx.DefaultPosition, title='RCL Update v1.0'):
        # MainFrame
        wx.Frame.__init__(self,
            parent, iid, title, pos, (720, 150),
            wx.DEFAULT_FRAME_STYLE ^ (wx.RESIZE_BORDER | wx.MINIMIZE_BOX | wx.MAXIMIZE_BOX))
        self.SetLabel('python wx StaticText and TextCtrl Test')
        panel = wx.Panel(self)
        w,h = self.GetSize()
        
        self.textCtrl = wx.TextCtrl(panel, -1, 'ttttttttttttkkkkkkk', (200, 20), (150, 100), wx.TE_READONLY | wx.TE_MULTILINE | wx.BORDER_NONE | wx.BRUSHSTYLE_TRANSPARENT)
        self.textCtrl.SetBackgroundColour(panel.BackgroundColour)

class RclApp(wx.App):
    # initialization here
    def OnInit(self):
        self.frame = MainFrame()
        self.frame.Show()
        self.SetTopWindow(self.frame)
        return True
    # cleanup here
    def OnExit(self):
        return True

def main():
    app = RclApp()
    app.MainLoop()
    
if __name__ == '__main__':
    main()
