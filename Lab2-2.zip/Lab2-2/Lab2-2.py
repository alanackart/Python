#_*_coding:utf-8_*_ 
 
import wx
import os, sys
from wx.lib.embeddedimage import PyEmbeddedImage

icon1 = PyEmbeddedImage(
   "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAMRJ"
    "REFUWIXtl90NgCAMhItxKDdxRjdxK3wyIQbb6x+a6L1qjw84qpS6rJUYlX0r3HMiIsmD85mk"
    "wmx9A4Dbxm+sAKdZ8zKSdm2duAJnsXVwSSXLGBWUAaQZpQJk6gd4HEDVB6ziQqwGuJp5jzEM"
    "0JtFRA8RMxDRA1yt2GKq0bBTcAdsAvB8Fa+1JgBvLlqIoSvQ81ADRPzGt14wQG//IiBCT0E7"
    "MAoRBmANZgjA3eAIVHojkiDcAMgsX3EzSrkda4PXe/8AgCFYR0sXzHYAAAAASUVORK5CYII=")
    
icon2 = PyEmbeddedImage(
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAUdJ"
    "REFUWIXNV0mOwyAQpCxL9q/MPCkvHPhBnmNOzCFhxNbNHqVOtoFeqssNQEyCvQ7LjUMb5L5v"
    "9jpsafFK7O6BC4KKvhbc+p0a8GGt/S1Okmft+ieAR1MAQp5SqLtqKmWBGthGrM5AfQAMxSMI"
    "xPGulUycqvv1zJWhMUAnTFoDvkHquQfqVgB+/gPxxwIGFlEe40tFSGU/9isGgDaANqjrA77z"
    "OIiaUoVrAg2kDKyoPWMzFCG1H1DU9wQb/QVlEU6sew67EB2Zj0Ce0n+lGSg5H9CKn/DWdRgp"
    "OW9gLs/ACPWNa5Ew4DYeyiiXfWOPgDag+0AukwU9ghbhDGdMOaAN7HXY3T8wJueBhXCln3Mi"
    "UjedbUGUX7odx2hR/pIARp0z8+LzwDOZEfXu2HRdBC9LuY/FK1euVfde1XK2PirC0TvmVDg2"
    "/gCeXoOhxQSuiAAAAABJRU5ErkJggg==")
    
icon3 = PyEmbeddedImage(
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAVFJ"
    "REFUWIXFV8txhTAMXDGZgXLSAU5JqSQlxXSQcuCkHGI8D1sycp48TxcGI6+X1Q8IA4zXmaV1"
    "2g4q16YRBHrs5QTeNLmyxT12IYYlaI+Y+RvADxF9ZgJmwLh38dDQygV7CMLiQaCy1+fAY2mk"
    "GIX81POtlRDaFfDJgcoujSErIL15ScBJnboK7g53TsarAlJPkKR3JJFzwHy4s5HaCe8Od1JB"
    "J9BDBmgTuu6PRPRx3tjKcFAXBICJtoOkOQ1gaPaflsuQtoOqTuhlYXHohB4k/q7Bn4A1PIJf"
    "m4B33FMYHivveQV6SAq++hdR6dzTkjuqR1ZgYN0DqeJSGGoCllGs+Um+wl4xB3idWfyi9ZiG"
    "jVY+lYysGz38eZ1ZzoG462D/zQ8Bj7aD6GSSWvEXgHcVpPHTYf6BKTDkIaRYa3SrA+0Gw0zA"
    "43AJ6ykFeg+WsH4BtmyOwHQrRHMAAAAASUVORK5CYII=")
    
class MyFrame(wx.Frame):
  def __init__(self, *args, **kwargs):
    wx.Frame.__init__(self, None, -1, u"WX上机练习14Lab2-2", size=(800, 500))
    self.SetBackgroundColour('white')
    panel = wx.Panel( self, -1 )
    self.SetIcon(icon1.GetIcon())
    wx.TextCtrl(self, -1, u"当前用的是图标：1", (0, 30),  style=wx.BORDER_NONE)
    # Create the menubar
    self.menuBar = wx.MenuBar()

    # and a menu 
    menu = wx.Menu()

    # add an item to the menu, using \tKeyName automatically
    # creates an accelerator, the third param is some help text
    menu.AppendSeparator()

    menu.Append(wx.ID_EXIT, u"&Exit\tCtrl+Shift+Del", u"")
    # bind the menu event to an event handler
    self.Bind(wx.EVT_MENU, self.OnClose, id=wx.ID_EXIT)

    # and put the menu on the menubar
    self.menuBar.Append(menu, u"&File")

    self.color = wx.Menu()
    # Radio items
    self.color.Append(201, u"图标1\tCtrl+1", u"", wx.ITEM_RADIO)
    self.color.Append(202, u"图标2\tCtrl+2", u"", wx.ITEM_RADIO)
    self.color.Append(203, u"图标3\tCtrl+3", u"", wx.ITEM_RADIO)
    
    self.Bind(wx.EVT_MENU_RANGE, self.OnColor,id=201,id2=203)

    self.menuBar.Append(self.color, u"&图标(I)")

    self.show = wx.Menu()
    self.show.Append(301, u"显示1\tCtrl+Shift+1", u"",  wx.ITEM_CHECK)
    self.show.Append(302, u"显示2\tCtrl+Shift+2", u"",  wx.ITEM_CHECK)
    self.show.Append(303, u"显示3\tCtrl+Shift+3", u"",  wx.ITEM_CHECK)
    self.show.Append(304, u"显示4\tCtrl+Shift+4", u"",  wx.ITEM_CHECK)
    self.Bind(wx.EVT_MENU_RANGE, self.OnShow,id=301,id2=304)
    self.menuBar.Append(self.show, u"&显示(D)")

    # and another menu 
    menu = wx.Menu()

    IdAbout = menu.Append(-1, u"&程序信息\tF1", u"Help tip")

    # bind the menu event to an event handler
    self.Bind(wx.EVT_MENU, self.OnAbout, IdAbout)

    # and put the menu on the menubar
    self.menuBar.Append(menu, u"&关于(A)")
    self.SetMenuBar(self.menuBar)
	
    self.CreateStatusBar()
    self.Bind(wx.EVT_PAINT, self.OnPaint)



  def OnColor(self, evt):
    item = self.GetMenuBar().FindItemById(evt.GetId())
    #text = item.GetText()
    iconid = evt.GetId()
    self.menuBar.EnableTop(2, True)
    wx.MessageBox(u"确定要修改吗？",
        "Confirmation", wx.YES_NO | wx.ICON_QUESTION, self)
    if iconid == 201:
        self.SetIcon(icon1.GetIcon())
    elif iconid == 202:
        self.SetIcon(icon2.GetIcon())
    elif iconid == 203:
        self.SetIcon(icon3.GetIcon())
        self.menuBar.EnableTop(2, False)
    wx.TextCtrl(self, -1, u"当前用的是图标：%d"%(iconid-200), (0, 30),  style=wx.BORDER_NONE)

  def OnShow(self, evt): 
    menuBar    = self.GetMenuBar()
    wx.TextCtrl(self, -1, u"", (150, 100),  style=wx.BORDER_NONE)
    wx.TextCtrl(self, -1, u"", (150, 150),  style=wx.BORDER_NONE)
    wx.TextCtrl(self, -1, u"", (250, 100),  style=wx.BORDER_NONE)
    wx.TextCtrl(self, -1, u"", (250, 150),  style=wx.BORDER_NONE)
    if menuBar.FindItemById(301).IsChecked():
         wx.TextCtrl(self, -1, u"显示1", (150, 100),  style=wx.BORDER_NONE)
    if menuBar.FindItemById(302).IsChecked():
        wx.TextCtrl(self, -1, u"显示2", (150, 150),  style=wx.BORDER_NONE)
    if menuBar.FindItemById(303).IsChecked():
        wx.TextCtrl(self, -1, u"显示3", (250, 100),  style=wx.BORDER_NONE)
    if menuBar.FindItemById(304).IsChecked():
        wx.TextCtrl(self, -1, u"显示4", (250, 150),  style=wx.BORDER_NONE)
    
  def OnAbout(self, evt):
    wx.MessageBox(u"第二次上机练习\n图标，菜单，加速键，消息框\n\n学号：1014*******\n姓名：****\n",
           u"WX Lab2", wx.OK | wx.ICON_INFORMATION, self)
	
  def OnClose(self, evt):
    self.Close()

if __name__ == u'__main__':
  app = wx.PySimpleApp()
  frame = MyFrame()
  frame.Show(True)
  app.MainLoop()
  
    #def OnPaint(self, evt):
  #  dc=wx.PaintDC(self)
  #  # draw something in client area
  #  evt.Skip()
      #item = self.GetMenuBar().FindItemById(evt.GetId())
      #showId 	   = evt.GetId()
    #showItemId = menuBar.FindItemById(showId)
    #panel = wx.Panel(self, wx.ID_ANY)
    #for i in irange(1, 4):
    #    for  smId in srange(301, 304):
    #        if menuBar.FindItemById(smid).IsChecked():
    #            wx.TextCtrl(self, -1, u"显示1"%i, (20 + (smId-301)%2*10, 20 + (smId-301)/2*10),  style=wx.BORDER_NONE)
    #self.Refersh()
    #self.parent.Update()
    #showid = evt.GetId()
    #else:
    #    wx.TextCtrl(self, -1, u"", (250, 150),  style=wx.BORDER_NONE)
    #    self.menuBar.Check(304, False)
    #self.parent.Update()
    #self.rich_text = wx.TextCtrl(self, -1, u'显示1', (200, 20), (150, 100), wx.TE_READONLY | wx.TE_MULTILINE | wx.BORDER_NONE | wx.BRUSHSTYLE_TRANSPARENT )
    #t1 = wx.TextCtrl(self, -1, u"显示1", (150, 100),  style=wx.BORDER_NONE)