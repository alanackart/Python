#_*_coding:utf-8_*_ 
 
import wx
import os, sys
from wx.lib.embeddedimage import PyEmbeddedImage

icon1 = PyEmbeddedImage(
   "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAMRJ"
    "REFUWIXtl90NgCAMhItxKDdxRjdxK3wyIQbb6x+a6L1qjw84qpS6rJUYlX0r3HMiIsmD85mk"
    "wmx9A4Dbxm+sAKdZ8zKSdm2duAJnsXVwSSXLGBWUAaQZpQJk6gd4HEDVB6ziQqwGuJp5jzEM"
    "0JtFRA8RMxDRA1yt2GKq0bBTcAdsAvB8Fa+1JgBvLlqIoSvQ81ADRPzGt14wQG//IiBCT0E7"
    "MAoRBmANZgjA3eAIVHojkiDcAMgsX3EzSrkda4PXe/8AgCFYR0sXzHYAAAAASUVORK5CYII=")
    
icon2 = PyEmbeddedImage(
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAUdJ"
    "REFUWIXNV0mOwyAQpCxL9q/MPCkvHPhBnmNOzCFhxNbNHqVOtoFeqssNQEyCvQ7LjUMb5L5v"
    "9jpsafFK7O6BC4KKvhbc+p0a8GGt/S1Okmft+ieAR1MAQp5SqLtqKmWBGthGrM5AfQAMxSMI"
    "xPGulUycqvv1zJWhMUAnTFoDvkHquQfqVgB+/gPxxwIGFlEe40tFSGU/9isGgDaANqjrA77z"
    "OIiaUoVrAg2kDKyoPWMzFCG1H1DU9wQb/QVlEU6sew67EB2Zj0Ce0n+lGSg5H9CKn/DWdRgp"
    "OW9gLs/ACPWNa5Ew4DYeyiiXfWOPgDag+0AukwU9ghbhDGdMOaAN7HXY3T8wJueBhXCln3Mi"
    "UjedbUGUX7odx2hR/pIARp0z8+LzwDOZEfXu2HRdBC9LuY/FK1euVfde1XK2PirC0TvmVDg2"
    "/gCeXoOhxQSuiAAAAABJRU5ErkJggg==")
    
icon3 = PyEmbeddedImage(
    "iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABHNCSVQICAgIfAhkiAAAAVFJ"
    "REFUWIXFV8txhTAMXDGZgXLSAU5JqSQlxXSQcuCkHGI8D1sycp48TxcGI6+X1Q8IA4zXmaV1"
    "2g4q16YRBHrs5QTeNLmyxT12IYYlaI+Y+RvADxF9ZgJmwLh38dDQygV7CMLiQaCy1+fAY2mk"
    "GIX81POtlRDaFfDJgcoujSErIL15ScBJnboK7g53TsarAlJPkKR3JJFzwHy4s5HaCe8Od1JB"
    "J9BDBmgTuu6PRPRx3tjKcFAXBICJtoOkOQ1gaPaflsuQtoOqTuhlYXHohB4k/q7Bn4A1PIJf"
    "m4B33FMYHivveQV6SAq++hdR6dzTkjuqR1ZgYN0DqeJSGGoCllGs+Um+wl4xB3idWfyi9ZiG"
    "jVY+lYysGz38eZ1ZzoG462D/zQ8Bj7aD6GSSWvEXgHcVpPHTYf6BKTDkIaRYa3SrA+0Gw0zA"
    "43AJ6ykFeg+WsH4BtmyOwHQrRHMAAAAASUVORK5CYII=")
icon3_checked = 0
    
class MyFrame(wx.Frame):
  def __init__(self, *args, **kwargs):
    wx.Frame.__init__(self, None, -1, u"WX上机练习14Lab2-2", size=(800, 500))
    self.SetBackgroundColour('grey')
    panel = wx.Panel( self, -1 )
    self.SetIcon(icon1.GetIcon())
    # Create the menubar
    self.menuBar = wx.MenuBar()

    # and a menu 
    menu = wx.Menu()

    # add an item to the menu, using \tKeyName automatically
    # creates an accelerator, the third param is some help text
    # that will show up in the statusbar
    self.IdCommand = wx.NewId()
    #menu.Append(self.IdCommand, u"命令(&R)\tCtrl+R", "This the text in the Statusbar")
    # bind the menu event to an event handler
    self.Bind(wx.EVT_MENU, self.OnCommand, id=self.IdCommand)

    menu.AppendSeparator()

    menu.Append(wx.ID_EXIT, u"&Exit\tCtrl+Shift+Del", u"")
    # bind the menu event to an event handler
    self.Bind(wx.EVT_MENU, self.OnClose, id=wx.ID_EXIT)

    # and put the menu on the menubar
    self.menuBar.Append(menu, u"&File")

    self.color = wx.Menu()
    # Radio items
    self.color.Append(201, u"图标1\tCtrl+1", u"", wx.ITEM_RADIO)
    self.color.Append(202, u"图标2\tCtrl+2", u"", wx.ITEM_RADIO)
    self.color.Append(203, u"图标3\tCtrl+3", u"", wx.ITEM_RADIO)
    self.Bind(wx.EVT_MENU_RANGE, self.OnColor,id=201,id2=203)

    self.menuBar.Append(self.color, u"&图标")
    #if self.menuBar.Check(202,True):	
    #    self.SetIcon(icon2.GetIcon())
    #    self.Refresh()
    #control = wx.Menu()
    ## Check items
    #control.Append(301, u"Enable", u"Enable/Disable BG change", wx.ITEM_CHECK)
    #self.menuBar.Append(control, u"Con&trol")
    #self.Bind(wx.EVT_MENU, self.OnControl,id=301)
    #self.menuBar.Check(301,True)	
    #self.changeable = True
    self.show = wx.Menu()
    self.show.Append(301, u"显示1\tCtrl+Shift+1", u"", wx.ITEM_RADIO)
    self.show.Append(302, u"显示2\tCtrl+Shift+2", u"", wx.ITEM_RADIO)
    self.show.Append(303, u"显示3\tCtrl+Shift+3", u"", wx.ITEM_RADIO)
    self.show.Append(304, u"显示4\tCtrl+Shift+4", u"", wx.ITEM_RADIO)
    self.Bind(wx.EVT_MENU_RANGE, self.OnShow,id=301,id2=304)
    self.menuBar.Append(self.show, u"&显示")

    # and another menu 
    menu = wx.Menu()

    IdAbout = menu.Append(-1, u"&程序信息\tF1", u"Help tip")

    # bind the menu event to an event handler
    self.Bind(wx.EVT_MENU, self.OnAbout, IdAbout)

    # and put the menu on the menubar
    self.menuBar.Append(menu, u"&关于")
    self.SetMenuBar(self.menuBar)
	
    self.CreateStatusBar()
    self.Bind(wx.EVT_PAINT, self.OnPaint)

  def OnPaint(self, evt):
    dc=wx.PaintDC(self)
    # draw something in client area
    evt.Skip()

  def OnCommand(self, evt):
    wx.MessageBox(u"Sorry,运行命令 not implemented yet！",
           "Message", 
		   wx.OK | wx.ICON_EXCLAMATION, self)

  def OnColor(self, evt):
    item = self.GetMenuBar().FindItemById(evt.GetId())
    #text = item.GetText()
    iconid = evt.GetId()
    wx.MessageBox(u"确定要修改吗？",
        u"Confirmation", wx.YES_NO | wx.ICON_QUESTION, self)

    #if self.changeable:
    #  self.SetBackgroundColour(text)
    #  self.Refresh()
    if iconid == 201:
        self.SetIcon(icon1.GetIcon())
    elif iconid == 202:
        self.SetIcon(icon2.GetIcon())
    elif iconid == 203:
        global icon3_checked    # Needed to modify global copy of globvar
        icon3_checked = 1
        self.SetIcon(icon3.GetIcon())
    return iconid
    #else:
    #  dc=wx.ClientDC(self)
    #  dc.SetTextForeground(u'red')
    #  dc.DrawText(u"不能改变BG!",100,50)
  def OnShow(self, evt): 
      global icon3_checked
      if icon3_checked == 203:
          dc=wx.ClientDC(self)
          dc.SetTextForeground(u'red')
          dc.DrawText(u"不能改变BG!",100,50)
         
      
  def OnControl(self, evt):
    self.changeable = evt.IsChecked()
    self.GetMenuBar().Enable(self.IdCommand, self.changeable)

  def OnAbout(self, evt):
    wx.MessageBox(u"第二次上机练习\n图标，菜单，加速键，消息框\n\n学号：1014*******\n姓名：****\n",
           u"WX Lab2", wx.OK | wx.ICON_INFORMATION, self)
	
  def OnClose(self, evt):
    self.Close()

if __name__ == u'__main__':
  app = wx.PySimpleApp()
  frame = MyFrame()
  frame.Show(True)
  app.MainLoop()
