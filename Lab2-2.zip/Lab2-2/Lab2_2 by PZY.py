# -*- coding: utf-8 -*-
import wx
class MyFrame(wx.Frame):
    def __init__(self, *args, **kwargs):
        wx.Frame.__init__(self, None, -1, u"WX第2次上机练习 14Lab2_2", size=(800, 600))
        icon = wx.Icon(name="icon1.ico", type=wx.BITMAP_TYPE_ICO)
        self.SetIcon(icon)
        self.SetBackgroundColour(u"LightGray")

        self.MenuBar = wx.MenuBar()
        #menu:File
        menu = wx.Menu()
        menu.Append(wx.ID_EXIT, u"Exit\tCtrl+Shift+Delete", u"")
        self.Bind(wx.EVT_MENU, self.OnClose, id=wx.ID_EXIT)
        self.MenuBar.Append(menu, u"&File")

        #menu:图标
        self.icon = wx.Menu()
        self.icon.Append(101, u"图标1\tCtrl+1", u"", wx.ITEM_RADIO)
        self.icon.Append(102, u"图标2\tCtrl+2", u"", wx.ITEM_RADIO)
        self.icon.Append(103, u"图标3\tCtrl+3", u"", wx.ITEM_RADIO)
        self.Bind(wx.EVT_MENU_RANGE, self.OnIcon, id = 101, id2 = 103)
        self.MenuBar.Append(self.icon, u"图标(&I)")
        self.MenuBar.Check(101,True)
        panel = wx.Panel(self, -1)
        wx.StaticText(panel, -1, u"当前使用的图标是：图标1", pos=(100,50))

        #menu:显示
        self.show = wx.Menu()
        self.show.Append(201, u"显示1\tCtrl+SHift+1", u"", wx.ITEM_CHECK)
        self.show.Append(202, u"显示2\tCtrl+SHift+2", u"", wx.ITEM_CHECK)
        self.show.Append(203, u"显示3\tCtrl+SHift+3", u"", wx.ITEM_CHECK)
        self.show.Append(204, u"显示4\tCtrl+SHift+4", u"", wx.ITEM_CHECK)
        self.Bind(wx.EVT_MENU_RANGE, self.OnShow, id = 201, id2 = 204)
        self.MenuBar.Append(self.show, u"显示(&D)")

        #menu:关于
        self.about = wx.Menu()
        self.about.Append(301, u"程序信息(&I)\tF1", u"")
        self.Bind(wx.EVT_MENU, self.OnAbout, id = 301)
        self.MenuBar.Append(self.about, u"关于(&A)")

    def OnAbout(self, evt):
        wx.MessageBox(u"WX第2次上机练习\n图标、菜单、加速键、消息框\n\n学号：\n", u"WXLab2", wx.OK |wx.ICON_INFORMATION, self)

    def OnShow(self, evt):
        id = evt.GetId() - 200
        if(evt.IsChecked()):
            if (id % 2):
                wx.StaticText(self, -1, u"显示%d" % id, pos=(150 + 50 * id, 200))
            else:
                wx.StaticText(self, -1, u"显示%d" % id, pos=(100 + 50 * id, 300))
        else:
            if (id % 2):
                wx.StaticText(self, -1, u" " * 10, pos=(150 + 50 * id, 200))
            else:
                wx.StaticText(self, -1, u" " * 10, pos=(100 + 50 * id, 300))

    def OnIcon(self, evt):
        id = evt.GetId() - 100
        if(wx.MessageBox(u"确认要修改吗？", u"Confirmation", wx.YES_NO | wx.ICON_INFORMATION, self)):
            self.SetIcon(wx.Icon(name="icon%d.ico" % id ,type=wx.BITMAP_TYPE_ICO))
            wx.StaticText(self, -1, u"当前使用的图标是：图标%d" % id, pos=(100,50))
            self.MenuBar.EnableTop(2, True)
            #self.show.Enable(201, True)
            #self.show.Enable(202, True)
            #self.show.Enable(203, True)
            #self.show.Enable(204, True)

        if(id == 3):
            self.MenuBar.EnableTop(2, False)
            #self.show.Enable(201, False)
            #self.show.Enable(202, False)
            #self.show.Enable(203, False)
            #self.show.Enable(204, False)

    def OnClose(self, evt):
        self.Close()

if __name__ == '__main__':
    app = wx.PySimpleApp()
    frame = MyFrame()
    frame.Show(True)
    app.MainLoop()
