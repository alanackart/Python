"""
Factory class for building wx widgets
"""
import wx
import image

class WxFactory(object):
    def __init__(self,frame):
        self.frame = frame
        self.catalog={}
      # Need a dummy menu as you can't create a MenuItem and add the menu later
        self.dummyMenu=wx.Menu()
        
        self.ID_BUILD = wx.NewId()
    
    def Menu(self,*items):
        menu = wx.Menu()
        for item in items:
            if isinstance(item,wx.MenuItem):
                item.SetMenu(menu)
                menu.AppendItem(item)
        return(menu)
        
    def MenuItem(self,catalog=None,bind=None,*args,**kw):
        item=wx.MenuItem(self.dummyMenu,*args,**kw)
        if catalog != None: self.catalog[catalog] = item
        if bind != None: self.frame.Bind(wx.EVT_MENU,bind,item)
        
        return item
    def MenuSeparator(self):
        return wx.MenuItem(self.dummyMenu,id=wx.ID_SEPARATOR)
        
    def Button(self,parent,id,ifile,tip=None,bind=None,sizer=None,catalog=None):
        button=wx.BitmapButton(parent,id,image.Bitmap(ifile))
        if tip!=None:button.SetToolTipString(tip)
        if catalog != None: self.catalog[catalog] = button
        if bind != None: self.frame.Bind(wx.EVT_BUTTON,bind,button)
        if sizer!=None: sizer.Add(button,0,wx.ALIGN_CENTER|wx.ALL,border=10)