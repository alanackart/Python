"""
Image handle will replace with img2py generated version
"""
import wx
import embedimg

def Icon(name):
    if name in embedimg.catalog: return embedimg.catalog[name].GetIcon()
    print "Icon %s not found" % name 
    return wx.Icon("images/" + name + ".png",wx.BITMAP_TYPE_ANY)
def Bitmap(name):
    if name in embedimg.catalog: return embedimg.catalog[name].GetBitmap()
    print "Bitmap %s not found" % name 
    return wx.Bitmap("images/" + name + ".png",wx.BITMAP_TYPE_ANY)