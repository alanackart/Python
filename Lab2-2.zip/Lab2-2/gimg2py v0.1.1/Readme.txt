gimg2py - a GUI wrapper for the wxPython img2py tool

Version 0.1.1
Date - 02 June 2010

gimg2py is intended to be a GUI wrapper for the wxPython img2py tool

It uses (obviously) Python and wxPython
For a sample of the output from gimg2py, see embedimg.py in this download

This is very much an alpha version but you are welcome to try it out.

To do:
About box
Enable/disable menu items according to program state.
Check for build/save etc when closing program or new document

