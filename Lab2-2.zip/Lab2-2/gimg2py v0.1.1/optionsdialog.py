import wx

class OptionsDialog(wx.Dialog):
    """
    Options dialog class
    """
    def __init__(self,flags):
        wx.Dialog.__init__(self,None,-1,"Options")
        check={}
        check["name"]=wx.CheckBox(self,-1,"Name Option")
        check["inclext"]=wx.CheckBox(self,-1,"Include file extension")
        check["catalog"]=wx.CheckBox(self,-1,"Generate catalog")
        check["compat"]=wx.CheckBox(self,-1,"Compatible Option")
        check["icon"]=wx.CheckBox(self,-1,"Generate Icon")
        sizer1=wx.BoxSizer(wx.VERTICAL)
        sizer2=wx.StaticBoxSizer(wx.StaticBox(self,-1,"Choose Options"),
                wx.VERTICAL)
        sizer3=wx.GridSizer(3,2)
        sizer2.AddF(sizer3,wx.SizerFlags(1))
        chkflags=wx.SizerFlags(1).Expand().Border(wx.ALL,10)
        sizer3.AddF(check["name"],chkflags)
        sizer3.AddF(check["inclext"],chkflags)
        sizer3.AddF(check["catalog"],chkflags)
        sizer3.AddSpacer(0)
        sizer3.AddF(check["compat"],chkflags)
        sizer3.AddF(check["icon"],chkflags)
        sizer1.AddF(sizer2,wx.SizerFlags(0).Expand().Border(wx.ALL,10))
        sizer1.AddF(self.CreateStdDialogButtonSizer(wx.CANCEL|wx.OK),
                 chkflags)
        self.SetSizerAndFit(sizer1)
        
        for chk in check.values():
            self.Bind(wx.EVT_CHECKBOX,self.OnCheck,chk)
        for flag,value in flags.items():
            check[flag].SetValue(value)
        self.check = check
        self.OnCheck(None)
        
    def OnCheck(self,e):
        " common routine for check boxes - enable disable subsidary boxes"
        self.check["inclext"].Enable(self.check["name"].GetValue())
        self.check["icon"].Enable(self.check["compat"].GetValue())
        
    def GetOptions(self):
        return dict((key,self.check[key].GetValue()) 
               for key in self.check.keys())
# Testing
if __name__ == "__main__":
    app = wx.PySimpleApp()
    OptionsDialog().ShowModal()